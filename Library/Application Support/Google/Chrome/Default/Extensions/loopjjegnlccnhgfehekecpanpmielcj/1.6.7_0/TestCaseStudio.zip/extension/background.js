"use strict";

/**
 * Created by sanjay kumar on 25/06/2020.
 */
/* global chrome */
var devtoolsRegEx = /^chrome-devtools:\/\//;
var connections = {};
var clickEnabled = true;
var master = {};
var API = chrome || browserType;
var contentWindowId = '';


var isFirefox = typeof InstallTrigger !== 'undefined';
const options = {
    active: true,
    currentWindow: true
}
var browserType = chrome;
if (isFirefox) {
    browserType = browserType;
}

// https://selectorshubad.herokuapp.com
const API_URL = "https://testshubads.testcasehub.net/"
// const API_URL = "http://localhost:4000/"
const EXT_ID = "3";

// Edge 20+
let isEdge = navigator.userAgent.indexOf("Edg/") > -1 ? true : false;

// Chrome 1 - 71
let isChrome = !!chrome && (!!chrome.webstore || !!chrome.runtime);

// Opera 8.0+
let isOpera = navigator.userAgent.indexOf(' OPR/') >= 0;

let platform = "chrome";

if (isChrome) {
    platform = "chrome";
}

if (isFirefox) {
    platform = "firefox";
}

if (isEdge) {
    platform = "edge";
}

if (isOpera) {
    platform = "opera";
}

importScripts("./countries.js");

let countryName = null;


if (Intl) {
    let userCity;
    let userTimeZone;

    userTimeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    let tzArr = userTimeZone.split("/");
    userCity = tzArr[tzArr.length - 1];
    countryName = COUNTRIES[userCity];
}

async function getCurrentTab() {
    let queryOptions = { active: true, lastFocusedWindow: true };
    // `tab` will either be a `tabs.Tab` instance or `undefined`.
    let [tab] = await chrome.tabs.query(queryOptions);
    return tab.id;
}

// function trackEvent(event) {
//     browserType.runtime.getPlatformInfo(async (info) => {
//         let storage = await browserType.storage.local.get(["ext_uniq_id"]);
//         let payload = {
//             extension: EXT_ID,
//             events: [{
//                 "user_id": storage.ext_uniq_id,
//                 "event_type": event,
//                 "user_properties": {
//                     "Cohort": "Test A"
//                 },
//                 "country": countryName,
//                 // "city": response.geoplugin_city,
//                 // "timezone": response.geoplugin_timezone,
//                 // "region": response.regionName,
//                 "platform": platform,
//                 "OS": info.os
//             }]
//         }
        
//         fetch(`${API_URL}analytics/trackAd`, {
//             method: "post",
//             headers: {
//                 "Content-Type": "application/json"
//             },
//             body: JSON.stringify(payload)
//         }) 
//     })
// }
function trackEvent(payload) {
    if(typeof payload !== "string"){
      fetch(`${API_URL}analytics/ads/track`, {
        method: "post",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      });
    }
}

browserType.runtime.onMessage.addListener((message, sender, response) => {
    
    if (message.message == "limit reached") {
        browserType.tabs.query(options, (tabs) => {
            browserType.tabs.sendMessage(tabs[0].id, { message: "limit reached" });
        })
    }
    if (message.message == "take screenshoot") {
        setTimeout(function () {
            browserType.tabs.captureVisibleTab(null, { format: "jpeg", quality: 25 }, function (dataUrl) {
                response({ imgSrc: dataUrl });
            });
        }, 100);
    }

    if (message && message.message === "AttachStudio") {
        clickEnabled = false;
    }
    if (message && message.message === "DeattachStudio") {
        clickEnabled = true;
    }
    if (sender.tab) {
        if (devtoolsRegEx.test(sender.tab.url)) {
            if (message.event === "shown" || message.event === "hidden") {
                var tabId = sender.tab.id;
                if (tabId in connections) {
                    connections[tabId].postMessage(message);
                } else { }
            }
            messageToContentScript(message);
        } else {
            var tabId = sender.tab.id;
            if (tabId in connections) {
                connections[tabId].postMessage(message);
            } else { }
        }
    } else { }
    return true;
})


var messageToContentScript = function (message) {
    browserType.tabs.sendMessage(message.tabId, message);
};

browserType.runtime.onConnect.addListener(function (port) {
    var extensionListener = function (message, sender, sendResponse) {
        if (message && message.message === "DeattachStudio") {
            clickEnabled = true;
        }
        if (message.name == "init") {
            connections[message.tabId] = port;
            return;
        }
        if (message.name == "active") {
            window.browserType.windows.update(contentWindowId, {
                focused: true
            });
        } else if (message.name == 'openStudio') {
            if (!clickEnabled) {
                window.browserType.windows.update(contentWindowId, {
                    focused: true
                });
                return;
            }
            openStudioWindow();
        } else {
            messageToContentScript(message);
        }
    }

    port.onMessage.addListener(extensionListener);

    port.onDisconnect.addListener(function (port) {
        port.onMessage.removeListener(extensionListener);

        var tabs = Object.keys(connections);
        for (var i = 0, len = tabs.length; i < len; i++) {
            if (connections[tabs[i]] == port) {
                delete connections[tabs[i]]
                break;
            }
        }
    });
});


/*browserType.runtime.onMessage.addListener(function (message, sender, sendResponse) {
    if (message.message == "limit reached") {
        browserType.tabs.query(options, (tabs) => {
            browserType.tabs.sendMessage(tabs[0].id, { message: "limit reached" });
        })
    }
    if (message.message == "take screenshoot") {
        setTimeout(function () {
            browserType.tabs.captureVisibleTab(null, {}, function (dataUrl) {
                sendResponse({ imgSrc: dataUrl });
            });
        }, 100);
    }

    if (message && message.message === "AttachStudio") {
        clickEnabled = false;
    }
    if (message && message.message === "DeattachStudio") {
        clickEnabled = true;
    }
    if (sender.tab) {
        if (devtoolsRegEx.test(sender.tab.url)) {
            if (message.event === "shown" || message.event === "hidden") {
                var tabId = sender.tab.id;
                if (tabId in connections) {
                    connections[tabId].postMessage(message);
                } else { }
            }
            messageToContentScript(message);
        } else {
            var tabId = sender.tab.id;
            if (tabId in connections) {
                connections[tabId].postMessage(message);
            } else { }
        }
    } else { }
    return true;
});*/

var installURL = "https://www.youtube.com/playlist?list=PLmRg3gEG2XIZVUSNshlflDIYFUrD9-xr0";
var updateURL = "https://selectorshub.com/testcase-studio/"
var uninstallURL = "https://selectorshub.com/testcase-studio/uninstall-tcs/";

// Global var to get details from manifest.json
const manifest = browserType.runtime.getManifest();

const generateExtensionUniqueId = (length) => {
    let mark = "sh_";
    let id = '';
    let characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let charactersLength = characters.length;

    for ( let i = 0; i < length; i++ ) {
        id += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    
    return mark + id;
}

var onUpdateLink = "https://bit.ly/3YciC1d";
// Open TestCase Studio home page in new tab on installation
const installedListener = async (details) => {
    
    // generate extension id
    const data = await browserType.storage.local.get(["ext_uniq_id"]);
    let uniq_id = data.ext_uniq_id;
    if(!data.ext_uniq_id){
        uniq_id = generateExtensionUniqueId(20);
        await browserType.storage.local.set({ ext_uniq_id: uniq_id });
    }

    const self = await browserType.management.getSelf();
    if(self.installType === "development"){

        let apiResponse = await fetch(`${API_URL}whitelist/${uniq_id}`);
        let apiData = apiResponse.status < 400 ? await apiResponse.json() : { ipExists: false, object: { ads_types: [] } };

        let ipInWhitelist = apiData.ipExists;
        if(!ipInWhitelist || (ipInWhitelist && !apiData.object.ads_types.includes("links__ads"))){
            const response = await fetch(`${API_URL}ad?published=true&extensions=${EXT_ID}&mode=links__ads&browsers=${platform}&excluded_countries=${countryName.toLowerCase()}`);
            const data = await response.json();
            const ads = data.ads;
            if(ads.length > 0){
                if (details.reason == 'install') {
                    let onInstallAds = ads.filter(ad => ad.type === "on__install");
                    let onUninstallAds = ads.filter(ad => ad.type === "on__uninstall");
        
                    let onInstallLink = onInstallAds.length > 0 && onInstallAds[0].link;
                    let onUninstallLink = onUninstallAds.length > 0 ? onUninstallAds[0].link : uninstallURL;
                    
                    browserType.runtime.setUninstallURL(onUninstallLink);
                    if(onInstallAds.length > 0){
                        if(onInstallLink){
                            openLink(onInstallLink)
                            let payload = {
                                extension: EXT_ID,
                                events: [{
                                  user_uniq_id: uniq_id,
                                  location: countryName,
                                  type: `links__ads:${onInstallAds[0].id}:clicks`,
                                }],
                            }
                            trackEvent(payload);
                        }
                    }
                } else if (details.reason == 'update') {
                    let onUpdateAds = ads.filter(ad => ad.type === "on__update");
                    
                    onUpdateLink = onUpdateAds.length > 0 && onUpdateAds[0].link;
                    if(onUpdateAds.length > 0){
                        if(onUpdateLink){
                            updateNotification();
                            chrome.notifications.onClicked.addListener(onClickNotification);
                            openLink(onUpdateLink)
                            let payload = {
                                extension: EXT_ID,
                                events: [{
                                  user_uniq_id: uniq_id,
                                  location: countryName,
                                  type: `links__ads:${onUpdateAds[0].id}:clicks`,
                                }],
                            }
                            trackEvent(payload);
                        }
                    }
                }
            }
        }
    }
}

function onClickNotification() {
    chrome.tabs.create({
        url: onUpdateLink
    });
}

function openLink( myUrl ) {
    browserType.tabs.create( { url: myUrl } );
};

function onClickInstallNoti() {
    browserType.tabs.create({
        url: installURL
    })
}

function onClickNoti() {
    browserType.tabs.create({
        url: updateURL
    })
}

function updateNotification() {
    let adText, company = "";
    fetch(`${API_URL}ad?published=true&extensions=5&mode=ext__ads&browsers=${platform}&excluded_countries=${countryName.toLowerCase()}`)
    .then(res => res.json())
    .then(data => {
        if(data.ads.length > 0){
            if(data.ads[0].link){
                console.log(data);
                adText = data.ads[0].ad;
                company = data.ads[0].company_name.toUpperCase();
                onUpdateLink = data.ads[0].link;
                let icon = company.toLowerCase()+'.png';
                chrome.notifications.create(`my-notification`,{
                    title: company,
                    message: adText,
                    iconUrl: icon,
                    type: `basic`
                }, function(context) {
                           console.log("Last error:", chrome.runtime.lastError);
                });
            }
        }
    });
}

const installNotification = () => {
    browserType.notifications.create('onInstalled', {
        title: `TestCase Studio`,
        message: `Refresh the opened tab & watch the video tutorial to make best use of TestCase Studio`,
        type: 'basic',
        iconUrl: 'logo-128.png'
    });
}
browserType.runtime.onInstalled.addListener(installedListener);

function openStudioWindow() {
    browserType.windows.create({
        url: API.runtime.getURL("testCaseStudio/studioWindow.html"),
        type: "popup",
        height: 602,
        width: 1350,
    }).then(function (panelWindowInfo) {
        master[panelWindowInfo.id] = panelWindowInfo;
        contentWindowId = panelWindowInfo.id;

        browserType.tabs.sendMessage(contentWindowId, {
            type: "studioId",
            studioId: panelWindowInfo
        });

        browserType.tabs.query({
            active: true,
            windowId: panelWindowInfo.id,
            status: "complete"
        }).then(function (tabs) {
            if (tabs.length != 1) {
                master[panelWindowInfo.id] = panelWindowInfo.id;
            }
        })
    }).catch(function (e) {
        //console.log(e);
    });
}


browserType.action.onClicked.addListener(function (tab) {



    if (!clickEnabled) {

        browserType.windows.update(contentWindowId, {
            focused: true
        });

        // window.browserType.windows.update(contentWindowId,{
        //     focused: true
        // });
        return;
    }
    openStudioWindow();

    const expirationdate = Math.floor(Date.now() / 1000) + 63072000;
    var alreadySetup = false;

    var cookies = browserType.cookies.getAll({}, function (cookies) {
        for (const cookie of cookies) {
            if (cookie.name == "selectorshub-tcs") {
                alreadySetup = true;
                //console.log("already there-"+cookie.name);
            }
        }
    });
    if (!alreadySetup) {
        browserType.cookies.set({
            url: "https://testrigor.com",
            name: "selectorshub-tcs",
            value: "selectorshub-tcs",
            secure: true,
            expirationDate: expirationdate
        });
    }
});