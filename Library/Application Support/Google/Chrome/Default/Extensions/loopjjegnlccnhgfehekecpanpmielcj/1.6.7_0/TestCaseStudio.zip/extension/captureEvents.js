var idAttr = document.querySelector('.id');
var classAttr = document.querySelector('.class');
var nameAttr = document.querySelector('.name');
var placeholder = document.querySelector('.placeholder');
var textXpath = document.querySelector('.textXpath');

var checkboxes = document.querySelectorAll(".chooseAttr");
var tablePlaceholder = document.querySelector('.tablePlaceholder');

var copyAllSteps = document.querySelector(".copyAllButton");
var copyAllData = document.querySelector('.copyAllData');
var copyAllExpRes = document.querySelector('.copyAllExpRes');
var copyAllXpath = document.querySelector('.copyAllXpath');
var copyAllCss = document.querySelector('.copyAllCss');

// var toggleHeader = document.getElementById('toggleHeader');
var fileName = document.querySelector('#downloadFileName input');

var recordButton = document.getElementById('record');
var recordIcon = document.getElementById('recordIcon');
var element = document.getElementById('records-grid');
var helperText = document.getElementById('helperText');
var save_btn = document.getElementById('save_btn');
var toggleElement = document.getElementById('inputToggle');
var xpathInput = document.getElementById('xpathInput');
var clearTestCase = document.getElementById('clearTestCase');
var alwaysTop = document.getElementById('alwaysTop');

var pauseBtnToolTip = document.querySelector(".pauseBtn.toolTip");
var toggleToolTip = document.querySelector(".toggle.toolTip");
let platform = "";
//var submitBtn=document.getElementById("submit_btn");
var email = document.getElementById("email");
var pass = document.getElementById("password");
var company = document.getElementById("company");
var registerBtn = document.getElementById("submit_btn");
// var loginLink=document.getElementById("login_a");
var spanLogin = document.getElementById("login");
let authenticated = false;
var screenToggler = document.getElementById("screenshotToggle");
screenToggler.classList.add("active");
screenToggler.classList.remove("inactive");
let screenshootEnabled=true;
let screenDataColumnChecked=true;
let isthereAnImage = false;
let actualImage;
let stepsArray = [];
var OS = window.navigator.userAgent.includes('Mac') ? "mac" : "windows";
let imagesArray = [];

let limitReached = false;

let countryName = null;


if (Intl) {
    let userCity;
    let userTimeZone;

    userTimeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    let tzArr = userTimeZone.split("/");
    userCity = tzArr[tzArr.length - 1];
    countryName = COUNTRIES[userCity];
}


// Opera 8.0+
var isOpera = (!!window.opr && !!opr.addons) || !!window.opera || navigator.userAgent.indexOf(' OPR/') >= 0;

// Firefox 1.0+
var isFirefox = typeof InstallTrigger !== 'undefined';

// Safari 3.0+ "[object HTMLElementConstructor]" 
var isSafari = /constructor/i.test(window.HTMLElement) || (function (p) {
    return p.toString() === "[object SafariRemoteNotification]";
})(!window['safari'] || (typeof safari !== 'undefined' && safari.pushNotification));

// Edge 20+
var isEdge = window.navigator.userAgent.indexOf("Edg/") > -1 ? true : false;

// Chrome 1 - 71
var isChrome = !!window.chrome && (!!window.chrome.webstore || !!window.chrome.runtime);

var reviewLink = document.querySelector(".review-link");

var browserType = chrome;

// Get the modal
var modal = document.getElementById("myModal");

// Get the image and insert it inside the modal - use its "alt" text as a caption

var modalImg = document.getElementById("img01");
if (isChrome) {
    //reviewLink.setAttribute("href","https://addons.mozilla.org/en-US/firefox/addon/testcase-studio/");
    platform = "chrome";
}

if (isFirefox) {
    reviewLink.setAttribute("href", "https://addons.mozilla.org/en-US/firefox/addon/testcase-studio/");
    browserType = chrome;
    platform = "firefox";
}

if (isOpera) {
    reviewLink.setAttribute("href", "https://addons.opera.com/en-gb/extensions/details/testcase-studio/");
    platform = "opera";
}

if (isEdge) {
    platform = "edge";
    reviewLink.setAttribute("href", "https://microsoftedge.microsoft.com/addons/detail/testcase-studio/jdglgpgchkgiciogpolofelfdfkdgfcg");
}

// https://shubads.testcasehub.net/
const API_URL = "https://testshubads.testcasehub.net/"
// const API_URL = "https://shubads.testcasehub.net/"
// const API_URL = "http://localhost:4000/"
const EXT_ID = "3";
const TOP_EXT_ID = "11";
const OFFER_EXT_ID = API_URL === "https://shubads.testcasehub.net/" ? 13 : 7;


//tablePlaceholder.innerText="1. Now start your testing.\r\n2. All actions will be converted in english sentence here.\r\n3. For each step unique selector will be generated.\r\n4. Turn on the driver command & set as per requirement to generate command.\r\n5. Download the test case or copy all steps.\r\n6. You can update the file name before exporting it.";

var recording = true;
var steps = [];
var xpathText = '';
var senderId = '';
var attrArr = `[, withid,withclass,withname,withplaceholder,withtext]`;

var interval = null;

var userEmail = 'Anonymous';


// Display System Information

let systemInfoContainer = document.querySelector("#system-information th");
let systemInfoCopyBtn = document.querySelector(".copy-sys-info");

let timezone = "UTC";
let now = "";
const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
  "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
];

function displaySystemInformation(){
  now = new Date();
  timezone = now.toLocaleDateString(undefined, {day:'2-digit',timeZoneName: 'short' }).substring(4);
  systemInfoContainer.innerHTML += `<span>OS: </span> ${sys.os.family || ""} ${sys.os.version || ""} <span class="dividor">|</span> <span>Browser: </span> ${sys.name || ""} ${sys.version.split(".")[0] || ""} <span class="dividor">|</span> <span>Resolution: </span> ${window.screen.availWidth}x${window.screen.availHeight} <span class="dividor">|</span> <span>Time: </span> ${now.getDate()} ${monthNames[now.getMonth()]} ${now.getFullYear()} / ${now.getHours()}:${now.getMinutes()}:${now.getSeconds()}  ${timezone}`
}

displaySystemInformation();

systemInfoCopyBtn.addEventListener("click", () => {
    navigator.clipboard.writeText(`OS: ${sys.os.family || ""} ${sys.os.version || ""} | Browser: ${sys.name || ""} ${sys.version.split(".")[0] || ""} | Resolution: ${window.screen.availWidth}x${window.screen.availHeight} | Time: ${now.getDate()} ${monthNames[now.getMonth()]} ${now.getFullYear()} / ${now.getHours()}:${now.getMinutes()}:${now.getSeconds()}  ${timezone}`);
    systemInfoCopyBtn.children[0].classList.remove("hideElement");

    setTimeout(() => {systemInfoCopyBtn.children[0].classList.add("hideElement");}, 300)
})

let queue = [];

const newStep = (message, sendResponse) => {
    if (screenshootEnabled && message.data.indexOf("Press Enter") !== 0) {

        chrome.runtime.sendMessage({
            message: "take screenshoot"
        }, (response) => {
            queue.forEach(msg => {
                if(msg.data.indexOf("Press Enter") !== 0){
                    if (!Boolean(steps.length)) {
                        steps.push({
                            step: 'Open website',
                            relXpath: '',
                            relCss: '',
                            dataText: msg.URL,
                            planeLabel: msg.URL,
                            passwordValue: "",
                            expRes: '',
                            screenImage: response.imgSrc
                        });
                    }
        
                    steps.push({
                        step: msg.data,
                        relXpath: msg.relXpath,
                        relCss: msg.relCss,
                        dataText: msg.dataText,
                        passwordValue: msg.passwordValue,
                        planeLabel: msg.planeLabel,
                        expRes: '',
                        screenImage: response.imgSrc
                    });
                    if (authenticated) {
                        displayRows();
                    }
                    sendResponse({
                        msg: "done"
                    });
                }else{
                    if (!Boolean(steps.length)) {
                        steps.push({
                            step: 'Open website',
                            relXpath: '',
                            relCss: '',
                            dataText: msg.URL,
                            passwordValue: "",
                            planeLabel: msg.URL,
                            expRes: ''
                        });
                    }
            
                    steps.push({
                        step: msg.data,
                        relXpath: msg.relXpath,
                        relCss: msg.relCss,
                        dataText: msg.dataText,
                        passwordValue: msg.passwordValue,
                        planeLabel: msg.planeLabel,
                        expRes: ''
                    });
                    
                    if (authenticated) {
                        displayRows();
                    }
                    sendResponse({
                        msg: "done"
                    });
                }
            })
            queue = [];
        });
    } else {
        if(queue[0] === message){
            if (!Boolean(steps.length)) {
                steps.push({
                    step: 'Open website',
                    relXpath: '',
                    relCss: '',
                    dataText: message.URL,
                    passwordValue: "",
                    planeLabel: message.URL,
                    expRes: ''
                });
            }
    
            steps.push({
                step: message.data,
                relXpath: message.relXpath,
                relCss: message.relCss,
                dataText: message.dataText,
                passwordValue: message.passwordValue,
                planeLabel: message.planeLabel,
                expRes: ''
            });
            
            if (authenticated) {
                displayRows();
            }
            sendResponse({
                msg: "done"
            });
            queue.shift();
        }
    }
    
}

chrome.runtime.onMessage.addListener(async function (message, sender, sendResponse) {

    senderId = sender.tab && sender.tab.id;
    if (message && message.type === 'windowEvent' && recording && message.data !== 'Click on aTag') {
        queue.push(message);
        browserType.storage.local.get([
            'screenDataColumn'], function (result) {
            if (result.screenDataColumn == "checked")
                screenDataColumnChecked = true;
        });
        newStep(message, sendResponse);

        //displayRows();

        //notifyMe('selectorsHub', message.data);

    }

    if (message && message.type === 'recorderAttr') {
        setAttr(message.data);
    }

    if (message && message.type === "verification" && recording) {
        if(senderId) browserType.tabs.sendMessage(senderId, { openStudio: true })
    }

    // if(message && message.data) {
    //     browser.tabs.query({}).then((tabs) => {

    //         var recorderWindow = tabs.find((a) => a.title === "selectorsHub Studio");

    //         window.chrome.windows.update(recorderWindow.windowId,{
    //             state: "normal", //minimized
    //         });

    //     });
    // }

});

var dataDisplay, expResultDisplay, xpathDisplay, cssDisplay = "";


function safeDisplay(text){
    let safe_text = text.replace(/</, "&lt;");
    safe_text = safe_text.replace(/>/, "&gt;");

    safe_text = safe_text.replace('/', "&#x2F;");

    safe_text = safe_text.replace('[', "&#91;");
    safe_text = safe_text.replace(']', "&#93;");

    safe_text = safe_text.replace("'", "&#39;");
    
    return safe_text;
}

function displayRows() {
    element.innerHTML = null;
    document.querySelector(".tablePlaceholder").style.display = "none";
    var secondTr = Boolean(toggleElement.classList.contains('active'));

    dataDisplay = dataColumnCheckbox.checked ? "" : "dataDisplay";
    expResultDisplay = expResultColumnCheckbox.checked ? "" : "expResultDisplay";
    xpathDisplay = xpathColumnCheckbox.checked ? "" : "xpathDisplay";
    cssDisplay = cssSelectorColumnCheckbox.checked ? "" : "cssDisplay";

    if (steps && steps.length) {
        if (steps.length == 50 && !limitReached) {
            chrome.runtime.sendMessage({ message: "limit reached" });
            limitReached = true;
           //alert('20 steps recorded, do you want to continue as it might cause performance issue.');
        }
        var commandWithDriver = command = "";
        var cssCommandWithDriver = cssCommand = "";
        if (secondTr && xpathInput.value && xpathInput.value.toLowerCase().includes('xpathvalue')) {
            for (let i = 0; i < steps.length; i++) {
                commandWithDriver = command = "";
                cssCommandWithDriver = cssCommand = "";
                let detectLabel = false;
                if (steps[i].relXpath && steps[i].relXpath.length) {
                    command = xpathInput.value.replace(/xpathvalue/i, steps[i].relXpath);
                    commandWithDriver = xpathInput.value.replace(/xpathvalue/i, `${steps[i].relXpath}`);
                }
                if (steps[i].relCss && steps[i].relCss.length) {
                    cssCommand = xpathInput.value.replace(/xpathvalue/i, steps[i].relCss);
                    cssCommandWithDriver = xpathInput.value.replace(/xpathvalue/i, `${steps[i].relCss}`);
                    cssCommandWithDriver = cssCommandWithDriver.includes("By.xpath")?cssCommandWithDriver.replace("By.xpath", "By.cssSelector"):cssCommandWithDriver.includes("By(xpath")?cssCommandWithDriver.replace("By(xpath", "By(cssSelector"):cssCommandWithDriver.includes("ByXPath")?cssCommandWithDriver.replace("ByXPath", "ByCssSelector"):cssCommandWithDriver.includes("cy.xpath")?cssCommandWithDriver.replace("cy.xpath", "cy.get"):cssCommandWithDriver.replace("cy.Xpath","cy.get");
                }
                if (xpathInput.value && xpathInput.value.toLowerCase().includes('labelvalue')) {
                    detectLabel = true;
                }

                if (screenDataColumnChecked) {
                    element.innerHTML += `
                <tr class="tableRow">
                    <td class='fixedColumns'>
                        <div class='tableData'>${i + 1}</div>
                    </td>
                    <td class='stepColumn'>
                        <div title="${safeDisplay(steps[i].step)}" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" contenteditable="true" class='tableData allSteps'>${safeDisplay(steps[i].step)}</div>
                    </td>
                    <td title="${steps[i].dataText}" class='dataColumn ${dataDisplay}'>
                        <div autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" contenteditable="true" class='tableData dataCol'>${steps[i].dataText}</div>
                    </td>
                    <td class='expResColumn ${expResultDisplay}'>
                        <div class="tableData expRes" autocomplete="off"  autocorrect="off" autocapitalize="off" spellcheck="false" contenteditable="true" title="enter your expected result here">${steps[i].expRes}</div>
                    </td>
                    <td class='xpathColumn ${xpathDisplay}'>
                       <div autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" contenteditable="true" title="${command}" class="tableData xpathData">${commandWithDriver}</div>
                    </td>
                    <td class='cssColumn ${cssDisplay}'>
                       <div autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" contenteditable="true" class="tableData cssData">${cssCommandWithDriver}</div>
                    </td>
                     <td class='screenshotColumn'>
                       <button  class='btn_screen' > <img class='screens' src='${steps[i].screenImage}' alt='undefined'  ></button> 
                    </td>
                    <td class="actionCol">
                        <button id='addStep'></button>
                        <button id='delButton'></button>
                    </td>
                </tr>
                `;

                } else {
                    element.innerHTML += `
                <tr class="tableRow">
                    <td class='fixedColumns'>
                        <div class='tableData'>${i + 1}</div>
                    </td>
                    <td class='stepColumn'>
                        <div title="${safeDisplay(steps[i].step)}" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" contenteditable="true" class='tableData allSteps'>${safeDisplay(steps[i].step)}</div>
                    </td>
                    <td title="${steps[i].dataText}" class='dataColumn ${dataDisplay}'>
                        <div autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" contenteditable="true" class='tableData dataCol'>${steps[i].dataText}</div>
                    </td>
                    <td class='expResColumn ${expResultDisplay}'>
                        <div class="tableData expRes" autocomplete="off"  autocorrect="off" autocapitalize="off" spellcheck="false" contenteditable="true" title="enter your expected result here">${steps[i].expRes}</div>
                    </td>
                    <td class='xpathColumn ${xpathDisplay}'>
                        <div autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" contenteditable="true" title="${command}" class="tableData xpathData">${commandWithDriver}</div>
                    </td>
                    <td class='cssColumn ${cssDisplay}'>
                        <div autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" contenteditable="true" class="tableData cssData">${cssCommandWithDriver}</div>
                    </td>
                    <td class="actionCol">
                        <button id='addStep'></button>
                        <button id='delButton'></button>
                    </td>
                </tr>
                `;
                }
                if (detectLabel) {
                    document.querySelector(`#label-${i}`).textContent = commandWithDriver.replace(/labelvalue/i, toCamelCase(steps[i].planeLabel));
                }
            }
        } else {
            for (let i = 0; i < steps.length; i++) {
                if (screenDataColumnChecked) {
                    element.innerHTML += `
                <tr class="tableRow">
                    <td class='fixedColumns'>
                        <div class='tableData'>${i + 1}</div>
                    </td>
                    <td class='stepColumn'>
                        <div title="${safeDisplay(steps[i].step)}" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" contenteditable="true" class='tableData allSteps'>${safeDisplay(steps[i].step)}</div>
                    </td>
                    <td title="${steps[i].dataText}" class='dataColumn ${dataDisplay}'>
                        <div autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" contenteditable="true" class='tableData dataCol'>${steps[i].dataText}</div>
                    </td>
                    <td class='expResColumn ${expResultDisplay}'>
                        <div class="tableData expRes" autocomplete="off"  autocorrect="off" autocapitalize="off" spellcheck="false" contenteditable="true" title="enter your expected result here">${steps[i].expRes}</div>
                    </td>
                    <td class='xpathColumn ${xpathDisplay}'>
                        <div autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" contenteditable="true" title="${steps[i].relXpath}" class="tableData xpathData xpathColor">${steps[i].relXpath}</div>
                    </td>
                    <td class='cssColumn ${cssDisplay}'>
                        <div autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" contenteditable="true" class="tableData cssData xpathColor">${steps[i].relCss}</div>
                    </td>
                     <td class='screenshotColumn'>
                       <button  class='btn_screen' > <img class='screens' src='${steps[i].screenImage}' alt='undefined'  ></button> 
                    </td>
                    <td class="actionCol">
                        <button id='addStep'></button>
                        <button id='delButton'></button>
                    </td>
                </tr>
                `;

                } else {
                    element.innerHTML += `
                <tr class="tableRow">
                    <td class='fixedColumns'>
                        <div class='tableData'>${i + 1}</div>
                    </td>
                    <td class='stepColumn'>
                        <div title="${safeDisplay(steps[i].step)}" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" contenteditable="true" class='tableData allSteps'>${safeDisplay(steps[i].step)}</div>
                    </td>
                    <td title="${steps[i].dataText}" class='dataColumn ${dataDisplay}'>
                        <div autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" contenteditable="true" class='tableData dataCol'>${steps[i].dataText}</div>
                    </td>
                    <td class='expResColumn ${expResultDisplay}'>
                        <div class="tableData expRes" autocomplete="off"  autocorrect="off" autocapitalize="off" spellcheck="false" contenteditable="true" title="enter your expected result here">${steps[i].expRes}</div>
                    </td>
                    <td class='xpathColumn ${xpathDisplay}'>
                        <div autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" contenteditable="true" title="${steps[i].relXpath}" class="tableData xpathData xpathColor">${steps[i].relXpath}</div>
                    </td>
                    <td class='cssColumn ${cssDisplay}'>
                        <div autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" contenteditable="true" class="tableData cssData xpathColor">${steps[i].relCss}</div>
                    </td>
                    <td class="actionCol">
                        <button id='addStep'></button>
                        <button id='delButton'></button>
                    </td>
                </tr>
                `;
                }
            }
            
        }
        addEventListenerToImages();
    }
    clickCell();
    if (steps.length == 0) {
        document.querySelector(".tablePlaceholder").style.display = "";
    }

};

function toCamelCase(s) {
    return s
        .replace(/_/g, " ")
        .replace(/\s(.)/g, function ($1) {
            return $1.toUpperCase();
        })
        .replace(/\s/g, '')
        .replace(/^(.)/, function ($1) {
            return $1.toLowerCase();
        });
}

//this is for delete and add new row
function clickCell() {
    var row = document.getElementById('records-grid').rows;
    for (var i = 0; i < row.length; i++) {
        row[i].cells[7].childNodes[3].addEventListener('click', function (e) {
            var rowIndex = this.parentNode.parentNode.rowIndex;
            // row.parentNode.removeChild(row);
            steps.splice(rowIndex - 1, 1);
            document.getElementById('records-grid').rows[rowIndex - 1].remove();
            addEventListenerToImages();
            //displayRows();
        });
        row[i].cells[7].childNodes[1].addEventListener('click', function (e) {

            var rowIndex = this.parentNode.parentNode.rowIndex;
            steps.splice(rowIndex, 0, {
                step: '',
                dataText: '',
                expRes: '',
                relXpath: '',
                relCss: ''
            });
            //addRow(rowIndex);

            displayRows();

        });

        row[i].childNodes[3].addEventListener('input', function (e) {
            if (e.data) {
                var rowIndex = this.parentNode.rowIndex;
                steps[rowIndex - 1].step = this.innerText;
                this.childNodes[1].classList.remove('removeOutline');
            } else {
                this.childNodes[1].classList.add('removeOutline');
            }
        });
        row[i].childNodes[5].addEventListener('input', function (e) {
            if (e.data) {
                var rowIndex = this.parentNode.rowIndex;
                steps[rowIndex - 1].dataText = this.innerText;
                this.childNodes[1].classList.remove('removeOutline');
            } else {
                this.childNodes[1].classList.add('removeOutline');
            }
        });

        row[i].childNodes[7].addEventListener('input', function (e) {
            if (e.data) {
                var rowIndex = this.parentNode.rowIndex;
                steps[rowIndex - 1].expRes = this.innerText;
                this.childNodes[1].classList.remove('removeOutline');
            } else {
                this.childNodes[1].classList.add('removeOutline');
            }
        });

        row[i].childNodes[9].addEventListener('input', function (e) {
            if (e.data) {
                var rowIndex = this.parentNode.rowIndex;
                steps[rowIndex - 1].relXpath = this.innerText;
                this.childNodes[1].classList.remove('removeOutline');
            } else {
                this.childNodes[1].classList.add('removeOutline');
            }
        });

        row[i].childNodes[11].addEventListener('input', function (e) {
            if (e.data) {
                var rowIndex = this.parentNode.rowIndex;
                steps[rowIndex - 1].relCss = this.innerText;
                this.childNodes[1].classList.remove('removeOutline');
            } else {
                this.childNodes[1].classList.add('removeOutline');
            }
        });

    }
};

toggleElement.addEventListener("click", function () {
    let ele = document.querySelector('.inputFeildContainer');
    let updatetitle = document.querySelector('#updatetitle');

    if (this.classList.contains("active")) {

        this.classList.remove("active");
        this.classList.add("inactive");

        xpathInput.classList.add('hidden');
        xpathInput.classList.remove('show');
        toggleToolTip.textContent = "Click to set driver command";
        // this.title = "Click to enable custom xpath";

        helperText.innerText = "Add custom driver command";

        // toggleHeader.innerText = 'Xpath';


        ele.classList.remove('showElement');
        ele.classList.add('remove');

        updatetitle.title = 'Click to copy all xpaths';

    } else {

        this.classList.remove("inactive");
        this.classList.add("active");
        toggleToolTip.textContent = "Click to disable command";

        xpathInput.classList.add('show');
        xpathInput.classList.remove('hidden');

        helperText.innerText = "";

        // toggleHeader.innerText = 'Command';


        ele.classList.add('showElement');
        ele.classList.remove('remove');

        updatetitle.title = 'Click to copy all commands';

    }
    displayRows();
});

recordButton.addEventListener('click', function (e) {
    if (recording) {
        recording = false;
        recordIcon.style.backgroundImage = "url(../../icons/pause_black.svg)";
        recordIcon.style.animation = "none";
        pauseBtnToolTip.textContent = "Click to start recording.";

        if(senderId) browserType.tabs.sendMessage(senderId, { stopRecording: true });

    } else {
        recording = true;
        recordIcon.style.animation = "blinker 1.0s cubic-bezier(.5, 0, 1, 1) infinite alternate";
        recordIcon.style.backgroundImage = "url(../../icons/tcStudio_redDot.svg)";
        pauseBtnToolTip.textContent = "Click to stop recording.";

        if(senderId) browserType.tabs.sendMessage(senderId, { openStudio: true });
    }
    return;
});

fileName.addEventListener("keyup", async (event) => {
    let key = event.which || event.keyCode;
            
    if (key === 13) { 
        if(event.target.value === "what is my sh_id"){
            const data = await browserType.storage.local.get(["ext_uniq_id"]);
            if(data.ext_uniq_id){
                const extensionIdContainer = document.createElement("div");
                extensionIdContainer.classList.add("extension__id__wrapper");
                
                extensionIdContainer.innerHTML = `
                    <div class="extension__id">
                        <div class="extension__id__close"></div>
                        <h4>Your unique sh_id</h4>
                        <div class="extension__id__container">
                            <input type="text" name="extension-id" id="extension-id" value="${data.ext_uniq_id}" readOnly />
                            <div class="extension__id__copy">
                                <div class="icon"></div>
                            </div>
                        </div>
                    </div>
                `
                let extensionIdInput = extensionIdContainer.querySelector("#extension-id");
                let closeBtn = extensionIdContainer.querySelector(".extension__id__close");
                let copyBtn = extensionIdContainer.querySelector(".extension__id__copy");

                closeBtn.addEventListener("click", () => extensionIdContainer.remove());

                copyBtn.addEventListener("click", async () => {
                    extensionIdInput.select();
                    document.execCommand("Copy");

                    copyBtn.style.backgroundColor = "#ffe0a6"
                    setTimeout(() => copyBtn.style.backgroundColor = "#ffffff", 300);
                })
                
                document.body.appendChild(extensionIdContainer);
                event.target.value = "";
            }
            return;
        }
    }
})

let upgradeContainer = document.querySelector("#upgrade-popup");
let upgradeConfirmBtn = document.querySelector("#upgrade-confirm");
let upgradeCancelBtn = document.querySelector("#upgrade-cancel");
let uiBlockAdsSettings;

upgradeConfirmBtn.addEventListener("click", () => {
    upgradeContainer.classList.add("hideElement");
})
upgradeCancelBtn.addEventListener("click", () => {
    upgradeContainer.classList.add("hideElement");
})

fetch(`${API_URL}settings/ui_block_ads`)
  .then(res => res.json())
  .then(data => {
    uiBlockAdsSettings = data.filter(s => s.extension === "tcs")[0];
  })

save_btn.addEventListener('click', function (e) {

    trackEvent("download");

    //var removeCookie= chrome.cookies.remove({url:"https://selectorshub.com",name:"TestCase Studio authentication"});
    /*removeCookie.then(()=>{
        alert("removed");
    },()=>{
        alert("error");
    })*/

    if(uiBlockAdsSettings.active === 1){
        browserType.storage.local.get(["save_count"], (data) => {
          if (data.save_count === undefined || data.save_count === null)
            return browserType.storage.local.set({ save_count: 0 });
          // if user click save 5 times then show popup
          if (data.save_count >= uiBlockAdsSettings.nb_actions - 1){
            // display popup
            upgradeContainer.classList.remove("hideElement");
            upgradeContainer.querySelector(".upgrade__popup__message").innerText = uiBlockAdsSettings.message;
            // reset counter
            browserType.storage.local.set({ save_count: 0 });
          } else {
            browserType.storage.local.set({ save_count: data.save_count + 1 });
          }
        });
      }else{
        browserType.storage.local.set({ save_count: 0 });
      }

    var xpathHeader = toggleToolTip.textContent.includes("Click to set driver command") ? "XPath" : "Command";

    if (steps && steps.length) {
        
        var header = [
            ["Step", "Data", "Exp Result", xpathHeader, "cssSelector"]
        ];
        let stps = document.querySelectorAll('.allSteps');
        let dataCol = document.querySelectorAll('.dataCol');
        let expRes = document.querySelectorAll('.expRes');
        let xpathData = document.querySelectorAll('.xpathData');
        let cssData = document.querySelectorAll('.cssData');
        //let screensData = document.querySelectorAll(".btn_screen > img");

        let data = steps.map((stp, ind) => {
            return {
                step: stps[ind].innerText,
                dataText: dataCol[ind].innerText,
                expRes: expRes[ind].innerText,
                relXpath: xpathData[ind].innerText,
                relCss: cssData[ind].innerText,
            }
        });
        
        data = data.map(stp => [stp.step, stp.dataText, stp.expRes, stp.relXpath, stp.relCss]);
        var testCase = header.concat(data);

        var name = fileName.value.replace(/\s/g, '');

        var pageDomainName = dataCol[0].innerText.replace(/.+\/\/|www.|\..+/g, '');
        var timeStamp = getFormattedTime();

        name = name ? name : pageDomainName + "-" + timeStamp;
        
        exportDataInToExcel(testCase, name);
        var zip = new JSZip();
        
        steps.forEach((step, index) => {
            if (step.screenImage) {
                isthereAnImage = true;
                var base64String = step.screenImage.replace("data:image/jpeg;base64,", "");
                zip.file((index+1) + "-" + step.step.replaceAll('"', "") + ".jpg", base64String, {
                    base64: true
                });
            }

        });
        if (isthereAnImage && screenDataColumnChecked) {
            zip.generateAsync({
                type: "blob"
            })
                .then(function (content) {

                    // Force down of the Zip file
                    saveAs(content, name+"_screenshots");
                });
        }
        // browser.tabs.sendMessage(senderId, {
        //     type: "downloadReport",
        //     data: testCase,
        //     fileName: name
        // });



    } else {
        showSnackbar('No data to save');
    }

});

function exportDataInToExcel(data, name) {
    let now = new Date();
    let csv = `OS: ${sys.os.family || ""} ${sys.os.version || ""} | Browser: ${sys.name || ""} ${sys.version.split(".")[0] || ""} | Resolution: ${window.screen.availWidth}x${window.screen.availHeight} | Time: ${now.getDate()} ${monthNames[now.getMonth()]} ${now.getFullYear()} / ${now.getHours()}:${now.getMinutes()}:${now.getSeconds()}  ${timezone}\n`;
    var isWindowsOS = window.navigator.userAgent.includes('Windows');

    Object.keys(data).forEach(function (key) {
        var i = 1;
        if (!dataColumnCheckbox.checked) {
            data[key].splice(i, 1);
        } else {
            i = i + 1;
        }

        if (!expResultColumnCheckbox.checked) {
            data[key].splice(i, 1);
        } else {
            i = i + 1;
        }

        if (!xpathColumnCheckbox.checked) {
            data[key].splice(i, 1);
        } else {
            i = i + 1;
        }

        if (!cssSelectorColumnCheckbox.checked) {
            data[key].splice(i, 1);
        }
    });

    data.forEach(function (row) {
        csv += isWindowsOS ? row.join(",") : row.join("\t");
        csv += "\n";
    });

    var a = window.document.createElement("a");
    a.href = window.URL.createObjectURL(new Blob([csv], {
        type: 'data:application/vnd.ms-excel;base64,'
    }));

    if (isWindowsOS) {
        a.download = name + `.csv`;
    } else {
        a.download = name + `.xls`;
    }

    // Append anchor to body.
    document.body.appendChild(a);
    //console.log(a);
    a.click();
   // a.dispatchEvent(new MouseEvent("click"));
    
    // Remove anchor from body
    //document.body.removeChild(a);
}

function getPageUrl() {
    return window.location.hostname;
}

function getFormattedTime() {
    var today = new Date();
    var y = today.getFullYear();
    // JavaScript months are 0-based.
    var m = today.getMonth() + 1;
    var d = today.getDate();
    var h = today.getHours();
    var mi = today.getMinutes();
    var s = today.getSeconds();
    return y + "-" + m + "-" + d + "-" + h + "-" + mi + "-" + s;
}

function showSnackbar(msg) {

    let showWarn = document.querySelector('#snackbar');
    showWarn.innerText = msg;
    showWarn.className = "show";
    setTimeout(function () {
        showWarn.className = showWarn.className.replace("show", "");
    }, 2000);

}

xpathInput.addEventListener('keyup', function (e) {

    xpathText = e.target.value;

    if (e.keyCode == 13) {
        if (!this.value.toLowerCase().includes('xpathvalue')) {
            this.classList.add('wrongXpath');
            showSnackbar('xpathValue keyword should be there in the command.');
            return;
        }
        displayRows();
        updateCPAttr();
    }
    if (!this.value.toLowerCase().includes('xpathvalue')) {
        this.classList.add('wrongXpath');
    } else if (this.value.toLowerCase().includes('xpathvalue')) {
        this.classList.remove('wrongXpath');
    }

});

window.onload = function (e) {
    /*
    function addScript() {
        var script = document.createElement('script');
        script.type = 'application/javascript';
        script.src = "../extension/script.js";
        document.head.appendChild(script);
    }
    addScript();
    */

    //open extension page
    trackEvent("open extension");
    var incognitoMode = browserType.extension.inIncognitoContext;
    var automatedWindow = navigator.webdriver;

    //commented below code to hide registration block

    // if (incognitoMode || automatedWindow) {
    //     document.getElementById("register_form").style.display = "none";
    //     document.querySelector(".container").style.display = "block";
    // } else {
    //     var cookies = chrome.cookies.getAll({}, function (cookies) {
    //         for (const cookie of cookies) {
    //             if (cookie.name == "TestCase Studio authentication") {
    //                 //alert("cookie found");
    //                 authenticated = true;
    //                 document.getElementById("register_form").style.display = "none";
    //                 tablePlaceholder.innerText = "1. Now start your testing.\r\n2. All actions will be converted in english sentence here.\r\n3. For each step unique selector will be generated.\r\n4. Turn on the driver command & set as per requirement to generate command.\r\n5. Download the test case or copy all steps.\r\n6. You can update the file name before exporting it.";

    //                 //console.log("already there-"+cookie.name);
    //             }
    //         }
    //     });
    // }
    //added below 3 line code to hide registration block and show placeholder
    authenticated = true;
    // document.getElementById("register_form").style.display = "none";
    tablePlaceholder.innerText = "1. Now start your testing.\r\n2. All actions will be converted in english sentence here.\r\n3. For each step unique selector will be generated.\r\n4. Turn on the driver command & set as per requirement to generate command.\r\n5. Download the test case or copy all steps.\r\n6. You can update the file name before exporting it.";
    browserType.tabs.query({}).then((tabs) => {
        tabs.forEach(async (tab) => {
            try{
                await browserType.tabs.sendMessage(tab.id, {
                    openStudio: true
                });
            }catch(_){}
        });
    });

    // chrome.identity.getProfileUserInfo(function(userInfo) {
    //     userEmail = userInfo.email || 'Anonymous';
    // });

}

window.onbeforeunload = function (event) {
    // browser.tabs.sendMessage(senderId, { closed: true });
    browserType.tabs.query({}).then((tabs) => {
        tabs.forEach(async (tab) => {
            await browserType.tabs.sendMessage(tab.id, {
                closed: true
            });
        });
    });
    window.removeEventListener('beforeunload');
};

function notifyMe(title, body) {
    if (Notification.permission === 'granted') {

        var notification = new Notification("TestCase Studio", {
            icon: '../../icons/tcStudio_black.svg',
            body: body
        });

        notification.onclick = function () {
            window.focus();
        };

    }

};

clearTestCase.addEventListener('click', function (e) {
    document.querySelector(".tablePlaceholder").style.display = "";
    element.innerHTML = null;
    steps = [];
    limitReached = false;
});

copyAllSteps.addEventListener("click", function () {
    trackEvent("copy steps");

    copyAllRowsToClipboard(".allSteps");
});

copyAllData.addEventListener('click', function () {
    trackEvent("copy data");
    copyAllRowsToClipboard(".dataCol");
});

copyAllExpRes.addEventListener('click', function () {
    trackEvent("copy exp result");

    copyAllRowsToClipboard(".expRes");
});

copyAllXpath.addEventListener('click', function () {
    trackEvent("copy Xpath");
    copyAllRowsToClipboard(".xpathData");
});

copyAllCss.addEventListener('click', function () {
    trackEvent("copy CSS selector");
    copyAllRowsToClipboard(".cssData");
});

function copyAllRowsToClipboard(elementSelectorToCopy) {
    //var text = document.querySelector(elementSelectorToCopy);

    let textarea = document.createElement('textarea');
    textarea.id = 't';
    // Optional step to make less noise on the page, if any!
    textarea.style.height = 0;
    // Now append it to your page somewhere, I chose <body>
    document.body.appendChild(textarea);
    // Give our textarea a value of whatever inside the div of id=containerid

    var allRowsData = document.querySelectorAll(elementSelectorToCopy);

    for (var i = 0; i < allRowsData.length; i++) {
        textarea.value = textarea.value + "\n" + allRowsData[i].innerText;
    }

    let selector = document.querySelector('#t');
    selector.select();
    document.execCommand('copy');
    // Remove the textarea
    document.body.removeChild(textarea);
}

function attributeChoicesOption() {
    // var userAttr = userAttrName.value.trim();
    // var idChecked = idCheckbox.checked?“withid”:“withoutid”;
    var idChecked = idAttr.checked ? "withid" : "withoutid";
    var classChecked = classAttr.checked ? "withclass" : "withoutclass";
    var nameChecked = nameAttr.checked ? "withname" : "withoutname";
    var placeholderChecked = placeholder.checked ? "withplaceholder" : "withoutplaceholder";
    var textChecked = textXpath.checked ? "withtext" : "withouttext";

    attrArr = `,${idChecked},${classChecked},${nameChecked},${placeholderChecked},${textChecked}`;
    browserType.tabs.sendMessage(senderId, {
        attrArray: attrArr
    });
}

checkboxes.forEach((checkbox) => {
    checkbox.addEventListener('click', function () {
        attributeChoicesOption();
        updateCPAttr();
    });
});

function setAttr(data) {

    idAttr.checked = data.idChecked;
    classAttr.checked = data.classChecked;
    nameAttr.checked = data.nameChecked;
    placeholder.checked = data.placeholderChecked;
    textXpath.checked = data.textChecked;

    // xpathInput.value = data.placeholderText;

}


function updateCPAttr() {
    browserType.tabs.sendMessage(senderId, {
        name: "updateCPAttr",
        data: {
            idChecked: idAttr.checked,
            classChecked: classAttr.checked,
            nameChecked: nameAttr.checked,
            placeholderChecked: placeholder.checked,
            textChecked: textXpath.checked,
            // placeholderText: xpathInput.value
        }
    });
};


var attributeFilter = document.querySelector(".attributeFilter");
var attrFilterBtn = document.querySelector(".attrFilterBtn");

attrFilterBtn.addEventListener("click", function (event) {

    if (attributeFilter.style.display === "" || attributeFilter.style.display === "none") {
        browserType.storage.local.set({
            'studioAttributeFilter': 'active'
        }, function () { });
        attributeFilter.style.display = "flex";
        attrFilterBtn.classList.remove("inactive");
        attrFilterBtn.classList.add("active");
    } else {
        browserType.storage.local.set({
            'studioAttributeFilter': 'inactive'
        }, function () { });
        attributeFilter.style.display = "none";
        attrFilterBtn.classList.remove("active");
        attrFilterBtn.classList.add("inactive");
    }
});


browserType.storage.local.get(['studioAttributeFilter'], function (result) {
    if (result.studioAttributeFilter == "active") {
        attributeFilter.style.display = "flex";
        attrFilterBtn.classList.remove("inactive");
        attrFilterBtn.classList.add("active");
    }
});


var columns = document.querySelector(".columns");
var uiConfigBtn = document.querySelector(".uiConfigBtn");

uiConfigBtn.addEventListener("click", function (event) {
    if (columns.style.display === "" || columns.style.display === "none") {
        columns.style.display = "flex";
    } else {
        columns.style.display = "none";
    }
});

var dataColumnCheckbox = document.querySelector(".chooseColumns.data");
var dataHeader = document.querySelector("#dataHeader");
dataColumnCheckbox.addEventListener("click", function () {
    var dataCol = document.querySelectorAll(".dataColumn");
    if (dataColumnCheckbox.checked) {
        dataHeader.style.display = "table-cell";
        showAllElements(dataCol);
        browserType.storage.local.set({
            'dataColumn': 'checked'
        }, function () { });
    } else {
        dataHeader.style.display = "none";
        hideAllElements(dataCol);
        browserType.storage.local.set({
            'dataColumn': 'unchecked'
        }, function () { });
    }
});

browserType.storage.local.get(['dataColumn'], function (result) {
    if (result.dataColumn && result.dataColumn != "checked") {
        dataHeader.style.display = "none";
        dataColumnCheckbox.checked = false;
    }
});

var expResultColumnCheckbox = document.querySelector(".chooseColumns.expResult");
var expResultHeader = document.querySelector("#expResHeader");
expResultColumnCheckbox.addEventListener("click", function () {
    var expRes = document.querySelectorAll(".expResColumn");
    if (expResultColumnCheckbox.checked) {
        expResultHeader.style.display = "table-cell";
        showAllElements(expRes);
        browserType.storage.local.set({
            'expResColumn': 'checked'
        }, function () { });
    } else {
        expResultHeader.style.display = "none";
        hideAllElements(expRes);
        browserType.storage.local.set({
            'expResColumn': 'unchecked'
        }, function () { });
    }
});

browserType.storage.local.get(['expResColumn'], function (result) {
    if (result.expResColumn && result.expResColumn != "checked") {
        expResultHeader.style.display = "none";
        expResultColumnCheckbox.checked = false;
    }
});


var xpathColumnCheckbox = document.querySelector(".chooseColumns.xpath");
var xpathHeader = document.querySelector("#xpathHeader");
xpathColumnCheckbox.addEventListener("click", function () {
    var xpathData = document.querySelectorAll(".xpathColumn");
    if (xpathColumnCheckbox.checked) {
        xpathHeader.style.display = "table-cell";
        showAllElements(xpathData);
        browserType.storage.local.set({
            'xpathDataColumn': 'checked'
        }, function () { });
    } else {
        xpathHeader.style.display = "none";
        hideAllElements(xpathData);
        browserType.storage.local.set({
            'xpathDataColumn': 'unchecked'
        }, function () { });
    }
});

browserType.storage.local.get(['xpathDataColumn'], function (result) {
    if (result.xpathDataColumn && result.xpathDataColumn != "checked") {
        xpathHeader.style.display = "none";
        xpathColumnCheckbox.checked = false;
    }
});

var cssSelectorColumnCheckbox = document.querySelector(".chooseColumns.cssSelector");
var cssSelectorHeader = document.querySelector("#cssSelectorHeader");
cssSelectorColumnCheckbox.addEventListener("click", function () {
    var cssData = document.querySelectorAll(".cssColumn");
    if (cssSelectorColumnCheckbox.checked) {
        cssSelectorHeader.style.display = "table-cell";
        showAllElements(cssData);
        browserType.storage.local.set({
            'cssDataColumn': 'checked'
        }, function () { });
    } else {
        cssSelectorHeader.style.display = "none";
        hideAllElements(cssData);
        browserType.storage.local.set({
            'cssDataColumn': 'unchecked'
        }, function () { });
    }
});

browserType.storage.local.get(['cssDataColumn'], function (result) {
    if (result.cssDataColumn && result.cssDataColumn != "checked") {
        cssSelectorHeader.style.display = "none";
        cssSelectorColumnCheckbox.checked = false;
    }
});

function hideAllElements(allElements) {
    allElements.forEach(function (ele) {
        ele.style.display = "none";
    });
}

function showAllElements(allElements) {
    allElements.forEach(function (ele) {
        ele.style.display = "table-cell";
    });
}

window.onclick = function (event) {
    if (event.target.className.includes("tableData")) {
        event.target.style.textOverflow = "initial";
    }
}

document.getElementById("execute_btn").addEventListener("click", function () {
    trackEvent("execute test on testrigor");

    if (steps && steps.length) {
        var testRigorLink = document.querySelector(".testRigorLink");

        var tempstep = steps[1].step;
        if(tempstep.includes("icon")){
            tempstep = tempstep.replace(" icon", "");
        }
        tempstep = tempstep.slice(0,5)=="Press"?tempstep.replace("Press", "type"):tempstep;

        var appUrl = encodeURIComponent(steps[0].dataText);

        var testRigorUrl = "https://app.testrigor.com/external-test?url="+appUrl+"&steps="+tempstep;
        for(var i=2; i<steps.length; i++){
            tempstep = steps[i].step;
            if(steps[i].dataText.includes("******")){
                tempstep = tempstep.replaceAll("******", steps[i].passwordValue);
            }
        
            if(tempstep.includes("icon")){
                tempstep = tempstep.replace(" icon", "");
            }
            tempstep = tempstep.slice(0,5)=="Press"?tempstep.replace("Press", "type"):tempstep;
            testRigorUrl = testRigorUrl+"%0A"+tempstep;
        }

        testRigorUrl = testRigorUrl + "&reference=selectorshub&utm_source=selectorshub&utm_medium=tcs";

        //console.log("before- "+testRigorUrl);
        testRigorLink.setAttribute("href", testRigorUrl);
    }else {
        showSnackbar('No steps to execute.');
    }
})

var country;
var city;

// function trackEvent(event) {
//     browserType.storage.local.get(["ext_uniq_id"], (storage) => {
//         let payload = {
//             extension: EXT_ID,
//             events: [{
//                 "user_id": storage.ext_uniq_id,
//                 "event_type": event,
//                 "user_properties": {
//                     "Cohort": "Test A"
//                 },
//                 "country": countryName,
//                 // "city": response.geoplugin_city,
//                 // "timezone": response.geoplugin_timezone,
//                 // "region": response.regionName,
//                 "platform": platform,
//                 "OS": OS
//             }]
//         }
        
//         fetch(`${API_URL}analytics/trackAd`, {
//             method: "post",
//             headers: {
//                 "Content-Type": "application/json"
//             },
//             body: JSON.stringify(payload)
//         }) 
//     });
// }
function trackEvent(payload){
    if(typeof payload !== "string"){
      fetch(`${API_URL}analytics/ads/track`, {
        method: "post",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      });
    }
  }
/*
registerBtn.addEventListener("click", function (e) {
    e.preventDefault();
    var timeStamp = getFormattedTime();
    //document.getElementById("register_form").style.display="none";
    if (registerBtn.value == "Register") {
        if (email.value !== "" && pass.value !== "") {
            if (email.value.includes("@") && email.value.includes(".")) {
                try {
                    OS = typeof OS == "undefined" ? "default" : OS;
                    platform = typeof platform == "undefined" ? "default" : platform;
                    city = typeof city == "undefined" ? "default" : city;
                    country = typeof country == "undefined" ? "default" : country;
                    timeStamp = typeof timeStamp == "undefined" ? "default" : timeStamp;
                    browserType.runtime.sendMessage({
                        type: "register",
                        OS: OS,
                        browser: platform,
                        city: city,
                        country: country,
                        email: email.value,
                        password: "111111",
                        company: company.value,
                        timeStamp: timeStamp
                    }, (response) => {
                        //alert(response.message);
                        setCookies();
                        authenticated = true;
                    });
                } catch (err) {
                    browserType.runtime.sendMessage({
                        type: "register",
                        OS: "default",
                        browser: "default",
                        city: "default",
                        country: "default",
                        email: email.value,
                        password: "111111",
                        company: company.value,
                        timeStamp: timeStamp
                    }, (response) => {
                        //alert(response.message);
                        setCookies();
                        authenticated = true;
                    });
                }
            } else {
                alert("Enter valid email.");
            }
        } else {
            alert("email and password required.");
        }
    }
    if (registerBtn.value == "Login") {
        //alert(registerBtn.value);
        if (email.value !== "") {
            chrome.runtime.sendMessage({
                type: "login",
                email: email.value
            }, (response) => {
                //alert(response.message);
                if (response.message == "registred") {
                    setCookies();
                    authenticated = true;
                    //alert("user registred");
                } else {
                    alert("This email is not registred, please click on register to create account.");
                }
            })
        } else {
            alert("Enter valid email ");
        }
    }
});
*/
// loginLink.addEventListener("click",function(){
//     if(this.innerText=="Login"){
//         company.style.display="none";
//         pass.style.display="none";
//         document.getElementById("form_title").innerHTML="Please Login to continue";
//         registerBtn.value="Login";
//         spanLogin.innerHTML="Don't have an account, ";
//         this.innerText="Register";
//         spanLogin.append(this);
//     }else{
//         company.style.display="block";
//         pass.style.display="block";
//         document.getElementById("form_title").innerHTML="Please Register to continue";
//         registerBtn.value="Register";
//         spanLogin.innerHTML="Existing User, ";
//         this.innerText="Login";
//         spanLogin.append(this);
//     }
// });

function setCookies() {
    const expirationdate = Math.floor(Date.now() / 1000) + 630720000;
    chrome.cookies.set({
        url: "https://selectorshub.com",
        name: "TestCase Studio authentication",
        value: "true",
        secure: true,
        expirationDate: expirationdate
    });
    document.getElementById("register_form").style.display = "none";
    tablePlaceholder.innerText = "1. Now start your testing.\r\n2. All actions will be converted in english sentence here.\r\n3. For each step unique selector will be generated.\r\n4. Turn on the driver command & set as per requirement to generate command.\r\n5. Download the test case or copy all steps.\r\n6. You can update the file name before exporting it.";
    //alert("cookie set up");       
}




// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks on <span> (x), close the modal
span.onclick = function () {
    modal.style.display = "none";
}

//add toggle to show/hide screenshots
screenToggler.addEventListener("click", function () {
    screenshootEnabled = !screenshootEnabled;
    if (this.classList.contains("active")) {
        this.classList.remove("active");
        this.classList.add("inactive");
        document.querySelectorAll(".screens").style.display="none";
    } else {
        this.classList.add("active");
        this.classList.remove("inactive");
    }
})

// hide or show screenshots table cell
var screenShotsCheckbox = document.querySelector(".chooseColumns.Screenshoot");
var screenshotHeader = document.querySelector("#screenshotHeader");
screenShotsCheckbox.addEventListener("click", function () {
    var screensData = document.querySelectorAll(".btn_screen");
    if (screenShotsCheckbox.checked) {
        screenshotHeader.style.display = "table-cell";
        showAllElements(screensData);
        browserType.storage.local.set({
            'screenDataColumn': 'checked'
        }, function () { });
        screenDataColumnChecked = true;
        displayRows();
        //alert('checked');
    } else {
        screenshotHeader.style.display = "none";
        hideAllElements(screensData);
        browserType.storage.local.set({
            'screenDataColumn': 'unchecked'
        }, function () { });
        screenDataColumnChecked = false;
        displayRows();
        //alert('not checked');
    }
});

browserType.storage.local.get(['screenDataColumn'], function (result) {
    if (result.screenDataColumn && result.screenDataColumn != "checked") {
        screenshotHeader.style.display = "none";
        screenShotsCheckbox.checked = false;
        screenDataColumnChecked = false;
    }
});
document.querySelector("#next").addEventListener('click', function () {
    document.querySelector("#previous").style.visibility = "visible";
    try{
        if (actualImage <= imagesArray.length - 1) {
            modalImg.src = imagesArray[actualImage+1].firstElementChild.src;
            document.querySelector('.screen_name').innerHTML = (actualImage+2) + "- " +stepsArray[actualImage+1].firstElementChild.innerHTML;
            actualImage++;
            if (actualImage == imagesArray.length-1)
                this.style.visibility = "hidden";
        }
    }catch(err){}

})
document.querySelector("#previous").addEventListener('click', function () {
    document.querySelector("#next").style.visibility = "visible";
    if (actualImage > 0) {
        modalImg.src = imagesArray[actualImage - 1].firstElementChild.src;
         document.querySelector('.screen_name').innerHTML = actualImage + "- " + stepsArray[actualImage-1].firstElementChild.innerHTML;
        actualImage--;
        if (actualImage == 0)
            this.style.visibility = "hidden";
    }

})

function addEventListenerToImages() {
    imagesArray = Array.from(document.querySelectorAll('.btn_screen')).filter((elem, index) => {
        if (elem.firstElementChild.src.includes("undefined"))
            return false;
        return true;
    });
    stepsArray = Array.from(document.querySelectorAll('.stepColumn')).filter((elem, index) => {
        if (elem.parentElement.querySelector('.screenshotColumn') && !elem.parentElement.querySelector('.screenshotColumn').firstElementChild.firstElementChild.src.includes("undefined"))
            return true;
        return false;
    });
    imagesArray.forEach((elem, index) => {
        elem.addEventListener("click", function () {
            if (!elem.firstElementChild.src.includes('undefined'))
                modal.style.display = "block";
            document.querySelector("#next").style.visibility = "visible";
            document.querySelector("#previous").style.visibility = "visible";
            modalImg.src = elem.querySelector("img").src;
            actualImage = index;
            document.querySelector('.screen_name').innerHTML = (actualImage+1) + "- " +stepsArray[actualImage].firstElementChild.innerHTML;
            if (index == 0)
                document.querySelector("#previous").style.visibility = "hidden";
            if (index == imagesArray.length - 1)
                document.querySelector("#next").style.visibility = "hidden";
        })
    })
}

document.addEventListener('keydown', (e) => {
    if (document.querySelector('.modal').style.display != 'none') {
        if (e.keyCode == '37')
        document.querySelector("#previous").click();
        if (e.keyCode == '39')
            document.querySelector("#next").click();
    } 
})


// AD Viewer - START
let adsText = document.querySelector(".ads__text");
let adsContainer = document.querySelector(".ads__container");
let adsViewer = document.querySelector(".ads__viewer");

let dummyVariable = "";
const buildAdText = (ad, images) => {
    const childrens = [];
    dummyVariable = ad;

    images.forEach((img, index) => {
        let arr = dummyVariable.split("");
        arr.splice(img.position + (index * 7), 0, "__img__");
        dummyVariable = arr.join("");
    })

    let span = document.createElement("span");
    span.innerText = dummyVariable;
    childrens.push(span);

    let embededImages = 0;
    childrens.forEach((child) => {
        let childNewText = child.innerText;
        while(child.innerText.indexOf("__img__") !== -1){
            childNewText = childNewText.replace("__img__", `<img src="${images[embededImages].imgURL}" />`)
            child.innerText = child.innerText.replace("__img__", "");
            embededImages++;
        }
        child.innerHTML = childNewText;
    })

    return childrens;
}

let offerAdsContainer = document.querySelector("#offer-countdown-ads");
let offerText = document.querySelector(".offer__text");
let offerCountdown = document.querySelector(".offer__countdown");
let offerAdsViewerPrevBtn = document.querySelector(".offer__navigate__prev__btn");
let offerAdsViewerNextBtn = document.querySelector(".offer__navigate__next__btn");
let offerInterval = null;

const updateOfferContent = (offer_countdown_enabled, offer_countdown_text, offer_countdown_end_at) => {
    if(offer_countdown_enabled){
      offerText.classList.remove("hideElement");
      offerCountdown.classList.remove("hideElement");
    
      offerText.innerText = offer_countdown_text;

      let now = Date.now();
      let difference = offer_countdown_end_at - now;
      if(difference < 0) return;

      let seconds = Math.floor(difference / 1000);
      let minutes = Math.floor(seconds / 60);
      let hours = Math.floor(minutes / 60);
      let days = Math.floor(hours / 24);

      offerCountdown.innerText = `${days}d : ${hours % 24}hr : ${minutes % 60}m : ${seconds % 60}s`;

      if(offerInterval) clearInterval(offerInterval);
      
      offerInterval = setInterval(() => {
        let now = Date.now();
        let difference = offer_countdown_end_at - now;
        let seconds = Math.floor(difference / 1000);
        let minutes = Math.floor(seconds / 60);
        let hours = Math.floor(minutes / 60);
        let days = Math.floor(hours / 24);

        offerCountdown.innerText = `${days}d : ${hours % 24}hr : ${minutes % 60}m : ${seconds % 60}s`;
      }, 1000);

    }else{
      offerText.classList.add("hideElement");
      offerCountdown.classList.add("hideElement");
    }
}

let offerAdsWrapper = document.querySelector(".offer__ads__container"); 

const appendAd = ({id, ad, link, images, background_color, extensions, text_color, border_color, company_name, display_time, type, action}) => {
   const elements = buildAdText(ad, images);
   
   const adContainer = document.createElement("a");
   adContainer.href = link;
   adContainer.id = `ad__${id}`;
   adContainer.className = "ad__template";
   adContainer.setAttribute("target", "_blank");
   adContainer.setAttribute("data-display-time", display_time);
   adContainer.setAttribute("title", ad);
   adContainer.style.backgroundColor = background_color;
   adContainer.style.border = "1px solid " + border_color;

   adContainer.innerHTML += `
        <div class="status__block" style="${type ? `display: block; background-color: ${type.color};` : "display: none;"}">${type?.name}</div>
        <div class="ad__text" style="display: flex; alignItems: center;">
            <div style="color: ${text_color}"></div>
        </div>
        <div class="ad__btn" style="background-color: ${action.background_color}">
            <div class="btn">
            <p style="color: ${action.text_color};">${action.name}</p>
                <div class="btn__icon">
                    <img src="${action.icon_url}" />
                </div>
            </div>
            </div>
    `;


    let adContentHolder = adContainer.querySelector(`.ad__text > div`);

    adContainer.addEventListener("click", async () => {
        let storage = await browserType.storage.local.get(["ext_uniq_id"]);
        let payload = {
            extension: EXT_ID,
            events: [{
            user_uniq_id: storage.ext_uniq_id,
            location: countryName,
            type: `ext__ads:${id}:clicks`,
            }],
        }
        trackEvent(payload);
    })

    elements.forEach((el) => {
        adContentHolder.appendChild(el);
    });

    if(extensions.includes(OFFER_EXT_ID.toString())){
        offerAdsWrapper.appendChild(adContainer);
    }else{
        adsContainer.appendChild(adContainer);
    }
}

let currentIndex = 1;
let _ads;
let tIntervals = [];
let tInterval = null;
let tStartTime = 0;
let tTimeRest = 0;
let tIsPaused = false;

let currentOfferIndex = 1;
let offerIntervals = [];
let offerAdsInterval = null;
let offerStartTime = 0;
let offerTimeRest = 0;
let offerIsPaused = false;

const applyInterval = (time) => {
    const adsTemplate = adsContainer.querySelectorAll(".ad__template");
    tIntervals.forEach(inv => clearInterval(inv));
    tIntervals = [];
    tInterval = setInterval(() => {
        if(adsTemplate[currentIndex]){
            tStartTime = Date.now();
            let toHideElement = adsContainer.querySelector(".ad__template.translate__left");
            
            adsTemplate[currentIndex].classList.remove("no__transition");
            toHideElement.querySelector(".ad__text > div").style.animation = "none";
            toHideElement.classList.add("hide__left");
            adsTemplate[currentIndex].classList.add("translate__left");

            if(adsTemplate[currentIndex].clientWidth >= adsContainer.clientWidth){
                let style = document.querySelector("#animation-style");

                let keyframes = `
                        @keyframes scrollText {
                            from{
                                transform: translateX(${adsTemplate[currentIndex].querySelector(".ad__text").clientWidth + 30}px);
                            }
                            to{
                                transform: translateX(-102%);
                            }
                        }`

                style.innerHTML = keyframes;
                adsTemplate[currentIndex].querySelector(".ad__text > div").style.animation = "scrollText 30s linear infinite";
            }

            let timeout = setTimeout(() => {
                
                toHideElement.classList.add("no__transition");
                toHideElement.classList.remove("hide__left");
                toHideElement.classList.remove("translate__left");
                
                clearTimeout(timeout);
                clearInterval(tInterval);
                tStartTime = 0;

                const adID = adsTemplate[currentIndex].id.replace("ad__", "");
                const targetedAd = _ads.filter(ad => ad.id === adID)[0];
                if(currentIndex === adsTemplate.length - 1){
                    currentIndex = 0;
                    tStartTime = Date.now();
                    applyInterval(targetedAd.display_time * 1000);
                    return;
                }
                currentIndex++
                tStartTime = Date.now();
                applyInterval(targetedAd.display_time * 1000);
            }, 300)
        }
    }, time);
    tIntervals.push(tInterval);
}

const applyOfferInterval = (time) => {
    const adsTemplate = offerAdsWrapper.querySelectorAll(".ad__template");
    offerIntervals.forEach(inv => clearInterval(inv));
    offerIntervals = [];
    offerAdsInterval = setInterval(() => {
        if(adsTemplate[currentOfferIndex]){
            offerStartTime = Date.now();
            let toHideElement = offerAdsWrapper.querySelector(".ad__template.translate__left");
            
            adsTemplate[currentOfferIndex].classList.remove("no__transition");
            toHideElement.querySelector(".ad__text > div").style.animation = "none";
            toHideElement.classList.add("hide__left");
            adsTemplate[currentOfferIndex].classList.add("translate__left");

            if(adsTemplate[currentOfferIndex].offsetWidth >= offerAdsWrapper.offsetWidth){
                let offerStyle = document.querySelector("#animation-style-offer");

                let keyframes = `
                        @keyframes offerScrollText {
                            from{
                                transform: translateX(${adsTemplate[currentOfferIndex].querySelector(".ad__text").clientWidth + 30}px);
                            }
                            to{
                                transform: translateX(-102%);
                            }
                        }`

                offerStyle.innerHTML = keyframes;
                adsTemplate[currentOfferIndex].querySelector(".ad__text > div").style.animation = "offerScrollText 30s linear infinite";
            }

            let timeout = setTimeout(() => {
                
                toHideElement.classList.add("no__transition");
                toHideElement.classList.remove("hide__left");
                toHideElement.classList.remove("translate__left");
                
                clearTimeout(timeout);
                clearInterval(offerAdsInterval);
                offerStartTime = 0;

                const adID = adsTemplate[currentOfferIndex].id.replace("ad__", "");
                const targetedAd = _ads.filter(ad => ad.id === adID)[0];
                updateOfferContent(targetedAd.offer_countdown_enabled, targetedAd.offer_countdown_text, targetedAd.offer_countdown_end_at);
                if(currentOfferIndex === adsTemplate.length - 1){
                    currentOfferIndex = 0;
                    offerStartTime = Date.now();
                    applyOfferInterval(targetedAd.display_time * 1000);
                    return;
                }
                currentOfferIndex++
                offerStartTime = Date.now();
                applyOfferInterval(targetedAd.display_time * 1000);
            }, 300)
        }
    }, time);
    offerIntervals.push(offerAdsInterval);
}

let adsViewerPrevBtn = document.querySelector(".navigate__prev__btn");
let adsViewerNextBtn = document.querySelector(".navigate__next__btn");

adsViewerPrevBtn.addEventListener("click", () => {
    let adsTemplates = adsContainer.querySelectorAll(".ad__template");
    currentIndex -= 2;
    if(currentIndex < 0){
        currentIndex = adsTemplates.length + currentIndex;
    }
    applyInterval(400);
})

adsViewerNextBtn.addEventListener("click", () => {
    applyInterval(400);
})

offerAdsViewerPrevBtn.addEventListener("click", () => {
  let adsTemplates = offerAdsWrapper.querySelectorAll(".ad__template");
  const adID = adsTemplates[currentOfferIndex].id.replace("ad__", "");
  const targetedAd = _ads.filter((ad) => ad.id === adID)[0];
  updateOfferContent(targetedAd.offer_countdown_enabled, targetedAd.offer_countdown_text, targetedAd.offer_countdown_end_at);
  currentOfferIndex -= 2;
  if (currentOfferIndex < 0) {
    currentOfferIndex = adsTemplates.length + currentOfferIndex;
  }
  applyOfferInterval(400);
});

offerAdsViewerNextBtn.addEventListener("click", () => {
  let adsTemplates = offerAdsWrapper.querySelectorAll(".ad__template");
  const adID = adsTemplates[currentOfferIndex].id.replace("ad__", "");
  const targetedAd = _ads.filter((ad) => ad.id === adID)[0];
  updateOfferContent(targetedAd.offer_countdown_enabled, targetedAd.offer_countdown_text, targetedAd.offer_countdown_end_at);

  applyOfferInterval(400);
});

const displayAds = (data) => {
    clearInterval(tInterval);
    clearInterval(offerAdsInterval);
    tStartTime = 0;
    offerStartTime = 0;
    _ads = data;
    data.forEach((ad, index) => appendAd(ad, index))
}
let adsSection = document.querySelector(".right__section");

browserType.storage.local.get(["ext_uniq_id"], (storageData) => {
    let ext_id = storageData.ext_uniq_id || "";
    
    fetch(`${API_URL}whitelist/${ext_id}`)
        .then(res => res.json())
        .then(response => {
            let footerAdsAllowed = true;
            let linksAdsAllowed = true;
    
            if(response.ipExists){
                footerAdsAllowed = !response.object.ads_types.includes("ext__ads");
                linksAdsAllowed = !response.object.ads_types.includes("links__ads");
            }
    
            if(footerAdsAllowed){
                fetch(`${API_URL}ad?published=true&extensions=${EXT_ID},${OFFER_EXT_ID}&mode=ext__ads&browsers=${platform}&excluded_countries=${countryName.toLowerCase()}`)
                .then(res => res.json())
                .then(data => {
                    if(data.ads.length > 0){
                        let offerAdsArray = data.ads.filter((ad) => ad.extensions.includes(OFFER_EXT_ID.toString()));
                        if(offerAdsArray.length === 1){
                            if(!offerAdsArray[0].offer_countdown_enabled) offerAdsContainer.style.border = "none";
                            offerAdsContainer.classList.remove("hideElement");
                            adsViewerPrevBtn.classList.add("hideElement");
                            adsViewerNextBtn.classList.add("hideElement");
                        }
                        if(offerAdsArray.length > 0){
                            adsSection.classList.remove("hideElement");
                            offerAdsContainer.classList.remove("hideElement");
                            updateOfferContent(offerAdsArray[0].offer_countdown_enabled, offerAdsArray[0].offer_countdown_text, offerAdsArray[0].offer_countdown_end_at);
                        }else{
                            offerAdsContainer.classList.add("hideElement");
                        }
                        displayAds(data.ads);
                        let normalAdsArray = data.ads.filter((ad) => !ad.extensions.includes(OFFER_EXT_ID.toString()));
                        if(normalAdsArray.length > 0 && data.ads[0].link){
                            const ads = adsContainer.querySelectorAll(".ad__template");

                            currentIndex = 1;

                            ads[0].classList.add("translate__left");
                        
                            let adText = ads[0].querySelector(`.ad__text`);
                        
                            let style = document.querySelector("#animation-style");
                            if(ads[0].clientWidth >= adsContainer.clientWidth){
                                // apply scrolling animation
                                let keyframes = `
                                @keyframes scrollText {
                                    from{
                                        transform: translateX(${adText.clientWidth + 30}px);
                                    }
                                    to{
                                        transform: translateX(-102%);
                                    }
                                }`
                        
                                style.innerHTML = keyframes;
                                ads[0].querySelector(".ad__text > div").style.animation = "scrollText 30s linear infinite";
                            }
                            
                            tStartTime = Date.now();
                            applyInterval(data.ads[0].display_time * 1000);
                        
                            ads.forEach(ad => {
                                ad.addEventListener("mouseenter", () => {
                                    if(!tIsPaused){
                                        ad.children[1].children[0].style.animationPlayState = "paused";
                                        clearInterval(tInterval);
                                        tTimeRest = Date.now() - tStartTime;
                                        tIsPaused = true;
                                    }
                                }) 
                                
                                ad.addEventListener("mouseleave", () => {
                                    if(tIsPaused){
                                        ad.children[1].children[0].style.animationPlayState = "running";
                                        let display_time_attribute = ad.getAttribute("data-display-time");
                                        let display_time = parseInt(display_time_attribute);
                                        if(display_time){
                                            tStartTime = Date.now() - tTimeRest;
                                            applyInterval(display_time * 1000 - tTimeRest);
                                            tIsPaused = false;
                                        }
                                    }
                                })       
                            })
                
                            // track ads views
                            // let payload = {
                            //     extension: EXT_ID,
                            //     events: [],
                            // }
                            // data.ads.forEach(ad => {
                            //     payload.events.push({
                            //         user_uniq_id: ext_id,
                            //         location: countryName,
                            //         type: `ext__ads:${ad.id}:views`,
                            //     });
                            // })
                            // trackEvent(payload);
                        }
                        if(offerAdsArray.length > 0){
                            const offerAds = offerAdsWrapper.querySelectorAll(".ad__template");
                            currentOfferIndex = 1;
                            offerAds[0].classList.add("translate__left");
                            let offerAdText = offerAds[0].querySelector(`.ad__text`);
                            let offerStyle = document.querySelector("#animation-style-offer");
                            if(offerAds[0].offsetWidth >= offerAdsWrapper.offsetWidth){
                                let offerKeyframes = `
                                @keyframes offerScrollText {
                                    from{
                                        transform: translateX(${offerAdText.clientWidth + 30}px);
                                    }
                                    to{
                                        transform: translateX(-102%);
                                    }
                                }`

                                offerStyle.innerHTML = offerKeyframes;
                                offerAds[0].querySelector(".ad__text > div").style.animation = "offerScrollText 30s linear infinite";
                            }

                            offerStartTime = Date.now();
                            applyOfferInterval(offerAdsArray[0].display_time * 1000);

                            offerAds.forEach(ad => {
                                ad.addEventListener("mouseenter", () => {
                                    if(!offerIsPaused){
                                        ad.children[1].children[0].style.animationPlayState = "paused";
                                        clearInterval(offerAdsInterval);
                                        offerTimeRest = Date.now() - offerStartTime;
                                        offerIsPaused = true;
                                    }
                                }) 
                                
                                ad.addEventListener("mouseleave", () => {
                                    if(offerIsPaused){
                                        ad.children[1].children[0].style.animationPlayState = "running";
                                        let display_time_attribute = ad.getAttribute("data-display-time");
                                        let display_time = parseInt(display_time_attribute);
                                        if(display_time){
                                            offerStartTime = Date.now() - offerTimeRest;
                                            applyOfferInterval(display_time * 1000 - offerTimeRest);
                                            offerIsPaused = false;
                                        }
                                    }
                                })  
                            });
                        }
                    }
                })
                .catch(err => console.log(err))
            }
            
            if(linksAdsAllowed){
                fetch(`${API_URL}ad?published=true&extensions=${EXT_ID}&mode=links__ads&browsers=${platform}&excluded_countries=${countryName.toLowerCase()}`)
                    .then(res => res.json())
                    .then(data => {
                    let onUninstallAds = data.ads.filter(ad => ad.type === "on__uninstall");
                    let onUninstallUrl = onUninstallAds.length > 0 ? onUninstallAds[0].link : "https://selectorshub.com/testcase-studio/uninstall-tcs/";
                    browserType.runtime.setUninstallURL(onUninstallUrl);
                    })
                    .catch(err => console.log(err))
            }
        })
});





// AD Viewer - END



// Top AD Viewer - START
let topAdsContainer = document.querySelector(".top_ads__container");
let topAdsViewer = document.querySelector(".top_ads__viewer");

let top_currentIndex = 1;
let _top_ads;
let top_tIntervals = [];
let top_tInterval = null;
let top_tStartTime = 0;
let top_tTimeRest = 0;
let top_tIsPaused = false;

const topAppendAd = ({id, ad, link, images, background_color, text_color, border_color, company_name, display_time, type, action}) => {
   const elements = buildAdText(ad, images);
   
   const adContainer = document.createElement("a");
   adContainer.href = link;
   adContainer.id = `top_ad__${id}`;
   adContainer.className = "top_ad__template";
   adContainer.setAttribute("target", "_blank");
   adContainer.setAttribute("top_data-display-time", display_time);
   adContainer.setAttribute("top_title", ad);
   adContainer.style.backgroundColor = background_color;
   adContainer.style.border = "1px solid " + border_color;

   adContainer.innerHTML += `
        <div class="top_status__block" style="${type ? `display: block; background-color: ${type.color};` : "display: none;"}">${type?.name}</div>
        <div class="top_ad__text" style="display: flex; alignItems: center;">
            <div style="color: ${text_color}"></div>
        </div>
        <div class="top_ad__btn" style="background-color: ${action.background_color}">
            <div class="top_btn">
            <p style="color: ${action.text_color};">${action.name}</p>
                <div class="top_btn__icon">
                    <img src="${action.icon_url}" />
                </div>
            </div>
            </div>
    `;


    let adContentHolder = adContainer.querySelector(`.top_ad__text > div`);

    adContainer.addEventListener("click", async () => {
        let storage = await browserType.storage.local.get(["ext_uniq_id"]);
        let payload = {
            extension: TOP_EXT_ID,
            events: [{
            user_uniq_id: storage.ext_uniq_id,
            location: countryName,
            type: `ext__ads:${id}:clicks`,
            }],
        }
        trackEvent(payload);
    })

    elements.forEach((el) => {
        adContentHolder.appendChild(el);
    });

    topAdsContainer.appendChild(adContainer);

}

const topApplyInterval = (time) => {
    const adsTemplate = document.querySelectorAll(".top_ad__template");
    top_tIntervals.forEach(inv => clearInterval(inv));
    top_tIntervals = [];

    top_tInterval = setInterval(() => {
        if(adsTemplate[top_currentIndex]){
            top_tStartTime = Date.now();
            let toHideElement = document.querySelector(".top_ad__template.top_translate__left");
            
            adsTemplate[top_currentIndex].classList.remove("top_no__transition");
            toHideElement.querySelector(".top_ad__text > div").style.animation = "none";
            toHideElement.classList.add("top_hide__left");
            adsTemplate[top_currentIndex].classList.add("top_translate__left");

            if(adsTemplate[top_currentIndex].clientWidth >= topAdsContainer.clientWidth){
                let style = document.querySelector("#animation-style");

                let keyframes = `
                        @keyframes scrollText {
                            from{
                                transform: translateX(${adsTemplate[top_currentIndex].querySelector(".top_ad__text").clientWidth + 30}px);
                            }
                            to{
                                transform: translateX(-102%);
                            }
                        }`

                style.innerHTML = keyframes;
                adsTemplate[top_currentIndex].querySelector(".top_ad__text > div").style.animation = "scrollText 30s linear infinite";
            }

            let timeout = setTimeout(() => {
                
                toHideElement.classList.add("top_no__transition");
                toHideElement.classList.remove("top_hide__left");
                toHideElement.classList.remove("top_translate__left");
                
                clearTimeout(timeout);
                clearInterval(top_tInterval);
                top_tStartTime = 0;

                const adID = adsTemplate[currentIndex].id.replace("top_ad__", "");
                const targetedAd = top_ads.filter(ad => ad.id === adID)[0];
                if(top_currentIndex === adsTemplate.length - 1){
                    top_currentIndex = 0;
                    top_tStartTime = Date.now();
                    topApplyInterval(targetedAd.display_time * 1000);
                    return;
                }
                top_currentIndex++
                top_tStartTime = Date.now();
                topApplyInterval(targetedAd.display_time * 1000);
            }, 300)
        }
    }, time);
    top_tIntervals.push(top_tInterval);
}

let topAdsViewerPrevBtn = document.querySelector(".top_navigate__prev__btn");
let topAdsViewerNextBtn = document.querySelector(".top_navigate__next__btn");

topAdsViewerPrevBtn.addEventListener("click", () => {
    let adsTemplates = document.querySelectorAll(".top_ad__template");
    top_currentIndex -= 2;
    if(top_currentIndex < 0){
        top_currentIndex = adsTemplates.length + top_currentIndex;
    }
    topApplyInterval(400, "prev");
})

topAdsViewerNextBtn.addEventListener("click", () => {
    topApplyInterval(400, "next");
})

const topDisplayAds = (data) => {
    clearInterval(top_tInterval);
    top_tStartTime = 0;
    top_ads = data;
    data.forEach((ad, index) => topAppendAd(ad, index))
}

browserType.storage.local.get(["ext_uniq_id"], (storageData) => {
    
    let top_ext_id = storageData.ext_uniq_id || "";
    
    fetch(`${API_URL}whitelist/${top_ext_id}`)
        .then(res => res.json())
        .then(response => {
            let footerAdsAllowed = true;
            let linksAdsAllowed = true;
            if(response.ipExists){
                footerAdsAllowed = !response.object.ads_types.includes("ext__ads");
                linksAdsAllowed = !response.object.ads_types.includes("links__ads");
            }
    
            if(footerAdsAllowed){
                fetch(`${API_URL}ad?published=true&extensions=${TOP_EXT_ID}&mode=ext__ads&browsers=${platform}&excluded_countries=${countryName.toLowerCase()}`)
                .then(res => res.json())
                .then(data => {
                    if(data.ads.length > 0){
                        if(data.ads[0].link){
                            topDisplayAds(data.ads);
                            const ads = document.querySelectorAll(".top_ad__template");
                            currentIndex = 1;
                            ads[0].classList.add("top_translate__left");
                        
                            let adText = ads[0].querySelector(`.top_ad__text`);
                        
                            let style = document.querySelector("#animation-style");
                            if(ads[0].clientWidth >= topAdsContainer.clientWidth){
                                // apply scrolling animation
                                let keyframes = `
                                @keyframes scrollText {
                                    from{
                                        transform: translateX(${adText.clientWidth + 30}px);
                                    }
                                    to{
                                        transform: translateX(-102%);
                                    }
                                }`
                        
                                style.innerHTML = keyframes;
                                ads[0].querySelector(".top_ad__text > div").style.animation = "scrollText 30s linear infinite";
                            }
                            tStartTime = Date.now();
                            topApplyInterval(data.ads[0].display_time * 1000);
                        
                            ads.forEach(ad => {
                                ad.addEventListener("mouseenter", () => {
                                    if(!top_tIsPaused){
                                        ad.children[1].children[0].style.animationPlayState = "paused";
                                        clearInterval(top_tInterval);
                                        top_tTimeRest = Date.now() - top_tStartTime;
                                        top_tIsPaused = true;
                                    }
                                }) 
                                
                                ad.addEventListener("mouseleave", () => {
                                    if(top_tIsPaused){
                                        ad.children[1].children[0].style.animationPlayState = "running";
                                        let display_time_attribute = ad.getAttribute("data-display-time");
                                        let display_time = parseInt(display_time_attribute);
                                        if(display_time){
                                            top_tStartTime = Date.now() - top_tTimeRest;
                                            topApplyInterval(display_time * 1000 - top_tTimeRest);
                                            top_tIsPaused = false;
                                        }
                                    }
                                })       
                            })
                
                            // track ads views
                            // let payload = {
                            //     extension: TOP_EXT_ID,
                            //     events: [],
                            // }
                            // data.ads.forEach(ad => {
                            //     payload.events.push({
                            //         user_uniq_id: top_ext_id,
                            //         location: countryName,
                            //         type: `ext__ads:${ad.id}:views`,
                            //     });
                            // })
                            // trackEvent(payload);
                        }
                    }
                })
                .catch(err => console.log(err))
            }
            
        })
});


// Top AD Viewer - END

// Footer AD Popup - START

const changeFooterStyles = (type) => {
    let infoBlock = document.querySelector(".infoBlock");
    let proButton = document.querySelector(".requestHeader.pro");
    let reviewLink = document.querySelector(".requestHeader.review-link");
    let adsInfoIcon = document.querySelector(".ads__info__icon");
    let changeLog = document.querySelector(".changelog");
    let spanBar = changeLog.previousElementSibling;
    let adsNavigationButton = document.querySelectorAll(".ads__navigation__btn");
    let adsViewer = document.querySelector(".ads__viewer");
    let popupActionsContainer = document.querySelector(".popup__actions__container");
    let themeToggle = document.querySelector(".theme-toggle");

    if(type === "popup"){
        adsNavigationButton.forEach(el => el.classList.add("ads__navigation__btn__popup"));
        infoBlock.classList.add("infoBlockPopUp");
        adsViewer.classList.add("ads__viewer__popup");
        proButton.classList.add("hideElement");
        reviewLink.classList.add("hideElement");
        changeLog.classList.add("hideElement");
        adsInfoIcon.classList.add("hideElement");
        spanBar.classList.add("hideElement");
        themeToggle.classList.add("hideElement");

        popupActionsContainer.classList.remove("hideElement");
    }else{
        adsNavigationButton.forEach(el => el.classList.remove("ads__navigation__btn__popup"));
        infoBlock.classList.remove("infoBlockPopUp");
        adsViewer.classList.remove("ads__viewer__popup");
        proButton.classList.remove("hideElement");
        reviewLink.classList.remove("hideElement");
        changeLog.classList.remove("hideElement");
        adsInfoIcon.classList.remove("hideElement");
        spanBar.classList.remove("hideElement");
        themeToggle.classList.remove("hideElement");

        popupActionsContainer.classList.add("hideElement");
    }
}

let keepAdsBtn = document.querySelector(".popup__action.keep__ads");
keepAdsBtn.addEventListener("click", () => {
    changeFooterStyles("footer");
});

browserType.storage.local.get(["popup_ads_sessions"], ({ popup_ads_sessions }) => {
    if(popup_ads_sessions === undefined){
        browserType.storage.local.set({ popup_ads_sessions: {
            count: 0,
            popped: false
        } });
    }else{
        browserType.storage.local.set({ popup_ads_sessions: {
            count: popup_ads_sessions.count + 1,
            popped: popup_ads_sessions.popped
        } });
    }
    
    fetch(`${API_URL}settings/ads_popup`)
        .then(res => res.json())
        .then(settings => {
            let tcsSettings = settings.filter(s => s.extension === "tcs")[0];
            let {active, time_control, sessions} = tcsSettings;
            if(active === 1){
                if(sessions === 1){
                    if(!popup_ads_sessions?.popped){
                      setTimeout(() => {
                          changeFooterStyles("popup");
                          browserType.storage.local.set({ popup_ads_sessions: {
                            count: 0,
                            popped: false
                          }});
                      }, time_control * 1000);
                    }
                  }if(popup_ads_sessions?.count < sessions - 1){
                    if(!popup_ads_sessions?.popped){
                        setTimeout(() => {
                            changeFooterStyles("popup");
                            browserType.storage.local.set({ popup_ads_sessions: {
                                count: popup_ads_sessions.count + 1,
                                popped: true
                            }});
                        }, time_control * 1000);
                    }
                }else{
                    browserType.storage.local.set({ popup_ads_sessions: {
                        count: 0,
                        popped: false
                    } });
                }
            }
        })
});

// Footer AD Popup - END

// License AD - START

browserType.storage.local.get(["license_ad_timestamp"], async ({ license_ad_timestamp }) => {
    let res = await fetch(`${API_URL}settings/license_ads`);
    let license_ads = res.status < 400 ? await res.json() : [];

    let tcsLicenseAd = license_ads.filter(ad => ad.extension === "tcs")[0];
    if(tcsLicenseAd && tcsLicenseAd.active === 1){
        if(Date.now() - license_ad_timestamp > tcsLicenseAd.every * 24 * 60 * 60 * 1000 || !license_ad_timestamp){
            let licenseAdContainer = document.querySelector("#license-popup");
    
            let licenseAcceptMessageContainer = document.querySelector(".accept__block label");
            let licenseAcceptMessageBtn = document.querySelector("a.license__accept");
            let licenseUpgradeMessageContainer = document.querySelector(".upgrade__block label");
            let upgradeLink = document.querySelector("a.license__upgrade");
            let acceptRadio = document.querySelector("#accept-input");
            let upgradeRadio = document.querySelector("#upgrade-input");
    
            licenseAcceptMessageContainer.innerText = tcsLicenseAd.accept_message;
            licenseUpgradeMessageContainer.innerText = tcsLicenseAd.upgrade_message;
            upgradeLink.href = tcsLicenseAd.link;
    
            licenseAdContainer.classList.remove("hideElement");
            
            acceptRadio.addEventListener("change", () => {
                if(acceptRadio.checked){
                    licenseAcceptMessageBtn.classList.remove("disabled");
                    upgradeLink.classList.add("disabled");
                }
            })
            upgradeRadio.addEventListener("change", () => {
                if(upgradeRadio.checked){
                    licenseAcceptMessageBtn.classList.add("disabled");
                    upgradeLink.classList.remove("disabled");
                }
            })
            licenseAcceptMessageBtn.addEventListener("click", () => {
                licenseAdContainer.classList.add("hideElement");
                browserType.storage.local.set({ license_ad_timestamp: Date.now() });
            })
    
            upgradeLink.addEventListener("click", () => {
                licenseAdContainer.classList.add("hideElement");
                browserType.storage.local.set({ license_ad_timestamp: Date.now() });
            })
        }
    }
})

// License AD - END

// Image Ads - START
let timeout;

function createImageContainer({id, company_name, display_time, link, image_url}, isFirst = false){
    let a = document.createElement("a");
    a.href = link;
    a.setAttribute("target", "_blank");
    a.setAttribute("data-dt", display_time);
    a.classList.add("image__link");
    if(isFirst) a.classList.add("displayed");
    a.innerHTML = `<img src="${API_URL.slice(0, -1) + image_url}" alt="${link}" /> `;

    a.addEventListener("click", async () => {
    let storage = await browserType.storage.local.get(["ext_uniq_id"]);
    let payload = {
        extension: EXT_ID,
        events: [
        {
            user_uniq_id: storage.ext_uniq_id,
            location: countryName,
            type: `image__ads:${id}:clicks`,
        }
        ],

    }
    trackEvent(payload);
    })

    return a;
}

function displayPrevAd(){
    clearTimeout(timeout);
    let display_time;
    let displayedImage = document.querySelector(".image__link.displayed");

    displayedImage.classList.remove("displayed");

    if(displayedImage.previousElementSibling){
    displayedImage.previousElementSibling.classList.add("displayed");
    display_time = displayedImage.previousElementSibling.getAttribute("data-dt");
    }else{
    displayedImage.parentElement.lastElementChild.classList.add("displayed");
    display_time = displayedImage.parentElement.lastElementChild.getAttribute("data-dt");
    }

    timeout = setTimeout(displayNextAd, 1000 * display_time);
}

function displayNextAd(){
    clearTimeout(timeout);
    let display_time;
    let displayedImage = document.querySelector(".image__link.displayed");
    displayedImage.classList.remove("displayed");

    if(displayedImage.nextElementSibling){
    displayedImage.nextElementSibling.classList.add("displayed");
    display_time = displayedImage.nextElementSibling.getAttribute("data-dt");
    }else{
    displayedImage.parentElement.firstElementChild.classList.add("displayed");
    display_time = displayedImage.parentElement.firstElementChild.getAttribute("data-dt");
    }

    timeout = setTimeout(displayNextAd, 1000 * display_time);
}

let prevBtn = document.querySelector(".prev__ad__img");
let nextBtn = document.querySelector(".next__ad__img");

prevBtn.addEventListener("click", displayPrevAd);
nextBtn.addEventListener("click", displayNextAd);

fetch(`${API_URL}ad?published=true&extensions=${EXT_ID}&mode=image__ads&browsers=${platform}&excluded_countries=${countryName.toLowerCase()}`)
.then(res => res.json())
.then(async data => {
    if(data.ads.length > 0){
    adsSection.classList.remove("hideElement");

    let imageAdsContainer = document.querySelector("#image-ads");
    imageAdsContainer.classList.remove("hideElement");

    let imagesContainer = imageAdsContainer.querySelector(".images__container");

    // let trackingPayload = {
    //     extension: EXT_ID,
    //     events: [],
    // }

    // let storage = await browserType.storage.local.get(["ext_uniq_id"]);
    data.ads.forEach((ad, index) => {
        let el = createImageContainer(ad, index === 0);
        imagesContainer.appendChild(el);

        if(index === 0){
        timeout = setTimeout(displayNextAd, 1000 * ad.display_time);
        }
        // trackingPayload.events.push({
        //   user_uniq_id: storage.ext_uniq_id,
        //   location: countryName,
        //   type: `image__ads:${ad.id}:views`,
        // })
        // track ads views
        // trackEvent(`views:${ad.id}:${ad.company_name}:image__ads`);
    })

    // trackEvent(trackingPayload);
    }
})
.catch(() => {})
  // Image Ads - END