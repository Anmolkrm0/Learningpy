/**
 * Created by sanjay kumar on 25/06/2020.
 */
/* global chrome */
"use strict";

var devtoolsRegEx = /^chrome-devtools:\/\//;
var connections = {};
var clickEnabled = true;
var master = {};
var API = chrome || browser;
var contentWindowId = '';

const API_URL = "https://testshubads.testcasehub.net/";
// const API_URL = "https://shubads.testcasehub.net/";
// const API_URL = "http://localhost:4000/";
const EXT_ID = "1";

var isFirefox = typeof InstallTrigger !== 'undefined';

var browserType = chrome;
if ( isFirefox ) {
    browserType = browser;
}

// Edge 20+
let isEdge = navigator.userAgent.indexOf("Edg/") > -1 ? true : false;

// Chrome 1 - 71
let isChrome = !!chrome && (!!chrome.webstore || !!chrome.runtime);

// Opera 8.0+
var isOpera = navigator.userAgent.indexOf(' OPR/') >= 0;

let platform = "chrome";

if (isChrome) {
    platform = "chrome";
}

if (isFirefox) {
    platform = "firefox";
}

if (isEdge) {
    platform = "edge";
}

if (isOpera) {
    platform = "opera";
}

importScripts("./countries.js");

let countryName = null;


if (Intl) {
    let userCity;
    let userTimeZone;

    userTimeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    if(userTimeZone){
      let tzArr = userTimeZone.split("/");
      userCity = tzArr[tzArr.length - 1];
      countryName = COUNTRIES[userCity];
    }else{
      countryName = "";
    }
}

// "use strict";
// self.importScripts( 'firebase-app.js', 'firebase-database.js', 'firebase-auth.js' );

var messageToContentScript = function ( message ) {
    browserType.tabs.sendMessage( message.tabId, message );
};

browserType.runtime.onConnect.addListener(function (port) {
  var extensionListener = function (message, sender, sendResponse) {
    if (message && message.message === "DeattachStudio") {
      clickEnabled = true;
    }
    if (message.name == "init") {
      connections[message.tabId] = port;
      return;
    }
    if (message.name && message.name === "block-side-panel") {
      if (!isOpera && !isFirefox) {
        if (message.isDevtoolsOpen === true) {
          chrome.sidePanel.setOptions({
            path: "../side-panel/devtoolsOpen.html",
            enabled: true,
          });
        } else {
          chrome.sidePanel.setOptions({
            path: "../side-panel/side-shub-panel.html",
            enabled: true,
          });
        }
      }
      return;
    }
    if (message.name == "active") {
      window.browserType.windows.update(contentWindowId, {
        focused: true,
      });
    } else if (message.name == "openStudio") {
      if (!clickEnabled) {
        window.browserType.windows.update(contentWindowId, {
          focused: true,
        });
        return;
      }
      openStudioWindow();
    } else {
      messageToContentScript(message);
    }
  };

  port.onMessage.addListener(extensionListener);

  port.onDisconnect.addListener(function (port) {
    port.onMessage.removeListener(extensionListener);

    // remove inspector from all tabs
    browserType.tabs.query({}, function (tabs) {
      tabs.forEach(function (tab) {
          messageToContentScript({ tabId: tab.id, name: "desactivate-inspector" })
      });
    });

    var tabs = Object.keys(connections);
    for (var i = 0, len = tabs.length; i < len; i++) {
      if (connections[tabs[i]] == port) {
        delete connections[tabs[i]];
        break;
      }
    }
  });
});

var relXpath = "";
var relCssSelector = "";
var jspath = "";
var absXpath = "";
var oldValue = [];
var contextOption = "active";
var relXpathChecked = "relXpathOn";
var cssSelectorChecked = "cssSelectorOff";
var jspathChecked = "jspathOff";
var absXpathChecked = "absXpathOff";

function deleteContextMenuItem(id) {
  try {
    browserType.contextMenus.remove(
      id,
      () => void browserType.runtime.lastError
    );
  } catch (err) {}
}

function createContextMenuItem(title, id) {
  contextOption = browserType.contextMenus.create({
    title: title,
    id: id,
    parentId: "parent",
    contexts: ["all"],
  });
  oldValue.push(contextOption);
}

let contextMenuAds = [];

function deleteContextMenuAds(cb) {
  try {
    browserType.contextMenus.removeAll(cb);
    contextMenuAds = [];
  } catch (_) {}
}

async function updateContextMenu() {
  const data = await browserType.storage.local.get(["ctxads"]);
  // delete prev items
  deleteContextMenuAds(async () => {
    await createContextMenu();
    if (data.ctxads) {
      data.ctxads.ads.forEach((item) => {
        let id = browserType.contextMenus.create({
          title: item.ad,
          id: item.id,
          parentId: "parent",
          contexts: ["all"],
        });
        contextMenuAds.push(id);
      });
    }
  });
}

// function trackEvent(event) {
//   browserType.runtime.getPlatformInfo(async (info) => {
//     let storage = await browserType.storage.local.get(["ext_uniq_id"]);
//     let payload = {
//       extension: EXT_ID,
//       events: [
//         {
//           user_id: storage.ext_uniq_id,
//           event_type: event,
//           user_properties: {
//             Cohort: "Test A",
//           },
//           country: countryName,
//           // "city": response.city,
//           // "timezone": response.timezone,
//           // "region": response.regionName,
//           // "carrier": response.isp,
//           platform: platform,
//           OS: info.os,
//         },
//       ],
//     };

//     fetch(`${API_URL}analytics/trackAd`, {
//       method: "post",
//       headers: {
//         "Content-Type": "application/json",
//       },
//       body: JSON.stringify(payload),
//     });
//   });
// }
function trackEvent(payload) {
  fetch(`${API_URL}analytics/ads/track`, {
    method: "post",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(payload),
  });
}


browserType.runtime.onMessage.addListener(function (
  message,
  sender,
  sendResponse
) {
  if (message.contextMenu) {
    contextMenu = message.contextMenu;
    browserType.storage.local.set({ contextMenu: contextMenu }, function () {});
    setTimeout(async function () {
      if (!contextMenu.includes("inactive")) {
        try {
          createContextMenu();
        } catch (err) {}
      } else {
        deletePreviousMenuItems();
      }
    }, 100);
  }

  if (message && message.action === "updateContextMenu") {
    updateContextMenu();
  }

  if (message && message.message === "AttachStudio") {
    clickEnabled = false;
  }
  if (message && message.message === "DeattachStudio") {
    clickEnabled = true;
  }
  if (sender.tab) {
    if (devtoolsRegEx.test(sender.tab.url)) {
      if (message.event === "shown" || message.event === "hidden") {
        var tabId = sender.tab.id;
        if (tabId in connections) {
          connections[tabId].postMessage(message);
        } else {
        }
      }
      messageToContentScript(message);
    } else {
      var tabId = sender.tab.id;
      if (tabId in connections) {
        connections[tabId].postMessage(message);
      } else {
      }
    }
  } else {
  }
  return true;
});

browserType.contextMenus.onClicked.addListener(function (info, tab) {
  browserType.tabs.query(
    { active: true, currentWindow: true },
    async function (tabs) {
      let data = await browserType.storage.local.get(["ctxads"]);
      if (info.menuItemId == "parent1") {
        browserType.tabs.sendMessage(tabs[0].id, { name: "copy id" });
      } else if (info.menuItemId == "parent2") {
        browserType.tabs.sendMessage(tabs[0].id, { name: "copy name" });
      } else if (info.menuItemId == "parent3") {
        browserType.tabs.sendMessage(tabs[0].id, { name: "copy relXpath" });
      } else if (info.menuItemId == "parent4") {
        browserType.tabs.sendMessage(tabs[0].id, { name: "copy relCssSelector" });
      } else if (info.menuItemId == "parent5") {
        browserType.tabs.sendMessage(tabs[0].id, { name: "copy jspath" });
      } else if (info.menuItemId == "parent7") {
        browserType.tabs.sendMessage(tabs[0].id, { name: "copy absXpath" });
      } else if (info.menuItemId == "parent6") {
        browserType.tabs.sendMessage(tabs[0].id, { name: "copy testRigor" });
      } else if (data.ctxads) {
        let targetedAd = data.ctxads.ads.filter(
          (ad) => ad.id === info.menuItemId
        )[0];
        if (targetedAd) {
          openLink(targetedAd.link);
          let storage = await browserType.storage.local.get(["ext_uniq_id"]);
          let payload = {
            extension: EXT_ID,
            events: [{
              user_uniq_id: storage.ext_uniq_id,
              location: countryName,
              type: `ctx__ads:${targetedAd.id}:clicks`,
            }],
          }
          trackEvent(payload);
        }
      }
    }
  );
});

var deletePreviousMenuItems = function () {
  if (oldValue.length > 0) {
    try {
      for (var i = 0; i < oldValue.length; i++) {
        browserType.contextMenus.remove(
          oldValue[i],
          () => void browserType.runtime.lastError
        );
      }
    } catch (err) {}
  }
  oldValue = [];
};

var installURL = "https://bit.ly/4_Playlist";
var updateURL = "https://www.selectorshub.com/changelog/";
var uninstallURL = "https://www.selectorshub.com/uninstall/";

// Global var to get details from manifest.json
const manifest = browserType.runtime.getManifest();

const generateExtensionUniqueId = (length) => {
  let mark = "sh_";
  let id = "";
  let characters =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  let charactersLength = characters.length;

  for (let i = 0; i < length; i++) {
    id += characters.charAt(Math.floor(Math.random() * charactersLength));
  }

  return mark + id;
};

// Open selectorsHub home page in new tab on installation
const installedListener = async (details) => {
  // generate extension id
  const data = await browserType.storage.local.get(["ext_uniq_id"]);
  let uniq_id = data.ext_uniq_id;
  if (!data.ext_uniq_id) {
    uniq_id = generateExtensionUniqueId(20);
    await browserType.storage.local.set({ ext_uniq_id: uniq_id });
  }

  const self = await browserType.management.getSelf();
  if (self.installType === "development") {
    let apiResponse = await fetch(`${API_URL}whitelist/${uniq_id}`);
    let apiData =
      apiResponse.status < 400
        ? await apiResponse.json()
        : { ipExists: false, object: { ads_types: [] } };

    let ipInWhitelist = apiData.ipExists;
    if (
      !ipInWhitelist ||
      (ipInWhitelist && !apiData.object.ads_types.includes("links__ads"))
    ) {
      const response = await fetch(
        `${API_URL}ad?published=true&extensions=${EXT_ID}&mode=links__ads&browsers=${platform}&excluded_countries=${countryName.toLowerCase()}`
      );
      const data = await response.json();

      const ads = data.ads;
        console.log(ads);
      if (ads.length > 0) {
        let onUninstallAds = ads.filter((ad) => ad.type === "on__uninstall");
        let onUninstallLink =
          onUninstallAds.length > 0 ? onUninstallAds[0].link : uninstallURL;
        browserType.runtime.setUninstallURL(onUninstallLink);

        if (details.reason == "install") {
          let onInstallAds = ads.filter((ad) => ad.type === "on__install");
          let onInstallLink = onInstallAds.length > 0 && onInstallAds[0].link;

          if (onInstallAds.length > 0) {
            onInstallLink && openLink(onInstallLink);
            let payload = {
              extension: EXT_ID,
              events: [{
                user_uniq_id: uniq_id,
                location: countryName,
                type: `links__ads:${onInstallAds[0].id}:clicks`,
              }],
            }
            trackEvent(payload);
          }
        } else if (details.reason == "update") {
          let onUpdateAds = ads.filter((ad) => ad.type === "on__update");
          let onUpdateLink = onUpdateAds.length > 0 && onUpdateAds[0].link;
          if (onUpdateAds.length > 0) {
            onUpdateLink && openLink(onUpdateLink);
            let payload = {
              extension: EXT_ID,
              events: [{
                user_uniq_id: uniq_id,
                location: countryName,
                type: `links__ads:${onUpdateAds[0].id}:clicks`,
              }],
            }
            trackEvent(payload);
          }
        }
      }
    }
  }
};

function onClickInstallNoti() {
  browserType.tabs.create({ url: installURL });
}
function onClickNoti() {
  browserType.tabs.create({ url: updateURL });
}

const updateNotification = () => {
  browserType.notifications.create({
    title: `SelectorsHub`,
    message: `Click here to see the Changelog of new version ${manifest.version}`,
    type: "basic",
    iconUrl: "logo-128.png",
  });
};

const installNotification = () => {
  browserType.notifications.create("onInstalled", {
    title: `SelectorsHub`,
    message: `Refresh the opened tab & watch the video tutorial to make best use of SelectorsHub`,
    type: "basic",
    iconUrl: "logo-128.png",
  });
};
browserType.runtime.onInstalled.addListener(installedListener);

var contextMenu = "active";

browserType.storage.local.get(["contextMenu"], function (result) {
  contextMenu = result.contextMenu;
  if (contextMenu) {
    if (!contextMenu.includes("inactive")) {
      createContextMenu();
    } else {
      deletePreviousMenuItems();
    }
  } else {
    createContextMenu();
  }

  // browserType.tabs.sendMessage(contextMenu);
});

// browserType.contextMenus.onClicked.addListener(function(info, tab) {
//     if (info.menuItemId == "parent1") {
//         copyValueToClipboard(relXpath);
//     }else if(info.menuItemId == "parent2"){
//         copyValueToClipboard(relCssSelector);
//     }else if(info.menuItemId == "parent3"){
//         copyValueToClipboard(jspath);
//     }else if(info.menuItemId == "parent4"){
//         copyValueToClipboard(absXpath);
//     }else if(info.menuItemId == "parent5"){
//         openLink("https://bit.ly/selectorshub_training");
//     }else if(info.menuItemId == "parent6"){
//         openLink("https://bit.ly/shub_training_udemy");
//     }
// });

function openLink(myUrl) {
  browserType.tabs.create({ url: myUrl });
}

// function copyValueToClipboard(valueToCopy) {
//     var el = document.createElement('textarea');
//     el.value = valueToCopy;
//     document.body.appendChild(el);
//     el.select();
//     document.execCommand('copy');
//     document.body.removeChild(el);
// };

// browserType.tabs.onUpdated.addListener( function (tabId, changeInfo, tab) {
//     try{
//       if (changeInfo.status == 'loading') {
//         browserType.tabs.executeScript(tab.id,{ file: 'contentScript.js', runAt: 'document_idle' },function(results){});
//         browserType.tabs.insertCSS(tab.id,{ file: 'contentScript.css', runAt: 'document_idle' },function(results){});
//       }
//   }catch(err){}
// })

async function createContextMenu() {
  contextOption = browserType.contextMenus.create({
    id: "parent",
    title: "SelectorsHub",
    contexts: ["all"],
  });
  oldValue.push(contextOption);

  contextOption = browserType.contextMenus.create({
    title: "Copy Id",
    id: "parent1",
    parentId: "parent",
    contexts: ["all"],
  });
  oldValue.push(contextOption);

  contextOption = browserType.contextMenus.create({
    title: "Copy Name",
    id: "parent2",
    parentId: "parent",
    contexts: ["all"],
  });
  oldValue.push(contextOption);

  contextOption = browserType.contextMenus.create({
    title: "Copy Relative XPath",
    id: "parent3",
    parentId: "parent",
    contexts: ["all"],
  });
  oldValue.push(contextOption);

  contextOption = browserType.contextMenus.create({
    title: "Copy Relative cssSelector",
    id: "parent4",
    parentId: "parent",
    contexts: ["all"],
  });
  oldValue.push(contextOption);

  contextOption = browserType.contextMenus.create({
    title: "Copy JS path",
    id: "parent5",
    parentId: "parent",
    contexts: ["all"],
  });
  oldValue.push(contextOption);

  contextOption = browserType.contextMenus.create({
    title: "Copy testRigor Path",
    id: "parent6",
    parentId: "parent",
    contexts: ["all"],
  });
  oldValue.push(contextOption);
  contextOption = browserType.contextMenus.create({
    title: "Copy abs XPath",
    id: "parent7",
    parentId: "parent",
    contexts: ["all"],
  });
  oldValue.push(contextOption);

  // const data = await chrome.storage.local.get(["ctxads"]);
  // if (data.ctxads) {
  //   let storage = await browserType.storage.local.get(["ext_uniq_id"]);
  //   let payload = {
  //     extension: EXT_ID,
  //     events: [],
  //   }
    
  //   if(data.ctxads.ads.length > 0){
  //     data.ctxads.ads.forEach((ad) => {
  //       payload.events.push({
  //         user_uniq_id: storage.ext_uniq_id,
  //         location: countryName,
  //         type: `ctx__ads:${ad.id}:views`,
  //       })
  //     });
  //     trackEvent(payload);
  //   }
  // }
}

function openStudioWindow() {
  browser.windows
    .create({
      url: API.runtime.getURL("testCaseStudio/studioWindow.html"),
      type: "popup",
      height: 600,
      width: 400,
    })
    .then(function (panelWindowInfo) {
      master[panelWindowInfo.id] = panelWindowInfo;
      contentWindowId = panelWindowInfo.id;

      browser.tabs.sendMessage(contentWindowId, {
        type: "studioId",
        studioId: panelWindowInfo,
      });

      browser.tabs
        .query({
          active: true,
          windowId: panelWindowInfo.id,
          status: "complete",
        })
        .then(function (tabs) {
          if (tabs.length != 1) {
            master[panelWindowInfo.id] = panelWindowInfo.id;
          }
        });
    })
    .catch(function (e) {
      //console.log(e);
    });
}

// browserType.runtime.onMessage.addListener((msg,sender,response)=>{
//     var id = "";
//     try{
//         id = msg.email.split("@")[0].replace(/[^\w\s]/gi, '');

//         /*var firebaseConfig = {
//             apiKey: "AIzaSyBIjD2AwjCkKPshyg8uQh4IDg_vCVj6Izc",
//             authDomain: "testoffline-8071d.firebaseapp.com",
//             databaseURL: "https://testoffline-8071d-default-rtdb.firebaseio.com/",
//             projectId: "testoffline-8071d",
//             storageBucket: "testoffline-8071d.appspot.com",
//             messagingSenderId: "223645501408",
//             appId: "1:223645501408:web:e7dbc0cb5c2e65b329cd85"
//         };*/
//         var firebaseConfig = {
//             apiKey: "AIzaSyC2ZG9EDE5yxiNhgoG4UJHEgnBVEC9r2g4",
//             authDomain: "selectorshub-6188d.firebaseapp.com",
//             databaseURL: "https://selectorshub-6188d-default-rtdb.firebaseio.com/",
//             projectId: "selectorshub-6188d",
//             storageBucket: "selectorshub-6188d.appspot.com",
//             messagingSenderId: "813208140204",
//             appId: "1:813208140204:web:8dd4489d47288035d86209",
//             measurementId: "G-DCR9BKEVRD"
//         };
//         // Initialize Firebase
//         //firebase.initializeApp(firebaseConfig);
//         const database = firebase.database();
//         id = "SHubId-" + id;
//         if (msg.type == "register") {

//             let ifExist=false;
//             var email = msg.email;
//             var pass = msg.password;

//             firebase.auth().createUserWithEmailAndPassword(email, pass).catch((error) => {
//                 //alert(error.message);
//                 // Handle Errors here.
//                 var errorCode = error.code;
//                 var errorMessage = error.message;
//                 /*this.setState({
//                   errorMessage,
//                   loading: false
//                 })*/
//             });
//             firebase.auth().onAuthStateChanged(function(user) {
//                 if (user) {
//                     // User is signed in.
//                     //alert("signed in")
//                     //response({message:"2"});
//                 }else {
//                     // No user is signed in.
//                 }
//             });

//             database.ref('/users/'+id).set({
//                     timeStamp: msg.timeStamp,
//                     browser:msg.browser,
//                     country:msg.country,
//                     city:msg.city,
//                     email:msg.email,
//                     company:msg.company,
//                     OS: msg.OS
//             })
//             .then(() => {
//                     firebase.database().goOffline();
//                 })
//             .catch((err)=>{
//                 let randomId = Math.floor((Math.random()*1000000) + 1);
//                 id = "SHubId-"+randomId;
//                 database.ref('/users/'+id).set({
//                     timeStamp: msg.timeStamp,
//                     browser:msg.browser,
//                     country:msg.country,
//                     city:msg.city,
//                     email:msg.email,
//                     company:msg.company,
//                     OS: msg.OS
//                 });
//             })
//             response({message:"created"});
//         }else if(msg.type=="login"){
//           /*  firebase.database().ref(`users/${id}`).once("value", snapshot => {
//                 if (snapshot.exists()){
//                     response({message:"registred"});
//                     //console.log(snapshot);
//                     //ifExist = true;
//                     //response({message:"1"});
//                 }else{
//                     response({message:"This email is not registred, please click on register to create account."});
//                 }
//             });*/
//         }
//     }catch(err){}
// })

// browserType.runtime.onMessage.addListener( ( msg, sender, response ) => {

//     if ( msg.type == "register" ) {
//         var id = msg.email.split( "@" )[0].replace( /[^\w\s]/gi, '' );

//         var firebaseConfig = {
//             apiKey: "AIzaSyC2ZG9EDE5yxiNhgoG4UJHEgnBVEC9r2g4",
//             authDomain: "selectorshub-6188d.firebaseapp.com",
//             databaseURL: "https://selectorshub-6188d-default-rtdb.firebaseio.com/",
//             projectId: "selectorshub-6188d",
//             storageBucket: "selectorshub-6188d.appspot.com",
//             messagingSenderId: "813208140204",
//             appId: "1:813208140204:web:8dd4489d47288035d86209",
//             measurementId: "G-DCR9BKEVRD"
//         };

//         firebase.initializeApp( firebaseConfig );
//         id = "SHubId-" + id;
//         let ifExist = false;
//         var email = msg.email;
//         var pass = msg.password;
//         firebase.auth().createUserWithEmailAndPassword( email, pass ).catch( ( error ) => {
//             var errorCode = error.code;
//             var errorMessage = error.message;
//         } );
//         firebase.auth().onAuthStateChanged( function ( user ) {

//             if ( user ) {
//                 // User is signed in.
//                 //alert("signed in")
//                 //response({message:"2"});
//             } else {
//                 // No user is signed in.
//             }

//         } );
//         firebase.database().ref( '/users/' + id ).set( {
//             timeStamp: msg.timeStamp,
//             browser: msg.browser,
//             country: msg.country,
//             city: msg.city,
//             email: msg.email,
//             company: msg.company,
//             OS: msg.OS
//         } )
//             .then( () => {
//                 firebase.database().goOffline();
//             } )
//             .catch( ( err ) => {
//                 let randomId = Math.floor( ( Math.random() * 1000000 ) + 1 );
//                 id = "SHubId-" + randomId;
//                 firebase.database().ref( '/users/' + id ).set( {
//                     timeStamp: msg.timeStamp,
//                     browser: msg.browser,
//                     country: msg.country,
//                     city: msg.city,
//                     email: msg.email,
//                     company: msg.company,
//                     OS: msg.OS
//                 } );
//             } );

//         response( {
//             message: "created"
//         } );

//     }
//     /*
//     if ( msg.type == "login" ) {
//     }
//     */
// } )

if (!isOpera && !isFirefox) {
  chrome.sidePanel
    .setPanelBehavior({ openPanelOnActionClick: true })
    .catch((error) => console.error(error));

  chrome.tabs.onUpdated.addListener(async (tabId, info, tab) => {
    if (!tab.url) return;
    if (info.status !== "complete") return;
    if (tab.url.startsWith("chrome://")) {
      // await chrome.sidePanel.setOptions({
      //     path: '../side-panel/error.html',
      //     enabled: true
      // });
    } else {
      await chrome.sidePanel.setOptions({
        path: "../side-panel/side-shub-panel.html",
        enabled: true,
      });
    }
  });
  chrome.tabs.onActivated.addListener(async (activeInfo) => {
    await chrome.sidePanel.setOptions({
      path: "../side-panel/side-shub-panel.html",
      enabled: true,
    });

    browserType.tabs.sendMessage(activeInfo.tabId, {
      name: "check-inspector-status",
    });
  });
}