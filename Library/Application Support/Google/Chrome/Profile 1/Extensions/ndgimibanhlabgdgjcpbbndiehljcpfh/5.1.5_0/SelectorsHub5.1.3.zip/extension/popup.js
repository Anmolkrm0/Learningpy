var openedRecorder = false;
var recorderOpen = document.querySelector('.recorderButton');

// Opera 8.0+
var isOpera = (!!window.opr && !!opr.addons) || !!window.opera || navigator.userAgent.indexOf(' OPR/') >= 0;

// Firefox 1.0+
var isFirefox = typeof InstallTrigger !== 'undefined';

// Safari 3.0+ "[object HTMLElementConstructor]" 
var isSafari = /constructor/i.test(window.HTMLElement) || (function (p) { return p.toString() === "[object SafariRemoteNotification]"; })(!window['safari'] || (typeof safari !== 'undefined' && safari.pushNotification));

// Edge 20+
var isEdge = window.navigator.userAgent.indexOf("Edg/") > -1 ? true : false;

// Chrome 1 - 71
var isChrome = !!window.chrome && (!!window.chrome.webstore || !!window.chrome.runtime);

var reviewLink = document.querySelector(".review-link");

var tcsDownloadLink = document.querySelector(".tcsDownloadLink");

var browserType = chrome;

if(isFirefox){
    reviewLink.setAttribute("href","https://addons.mozilla.org/en-US/firefox/addon/selectorshub/");
    browserType = browser;
    document.querySelector("body").style.width = "343px";
    document.querySelector(".demoPic").style.marginLeft = "96px";
    tcsDownloadLink.setAttribute("href","https://addons.mozilla.org/en-US/firefox/addon/testcase-studio/");
}

if(isOpera){
    reviewLink.setAttribute("href","https://addons.opera.com/en-gb/extensions/details/selectorshub/");
    tcsDownloadLink.setAttribute("href","https://addons.opera.com/en-gb/extensions/details/testcase-studio/");
}

if(isEdge){
    reviewLink.setAttribute("href","https://microsoftedge.microsoft.com/addons/detail/selectorshub/iklfpdeiaeeookjohbiblmkffnhdippe");
    tcsDownloadLink.setAttribute("href","https://microsoftedge.microsoft.com/addons/detail/testcase-studio/jdglgpgchkgiciogpolofelfdfkdgfcg");
}

var OS = window.navigator.userAgent.includes('Mac')?"mac":"windows";
if(!OS.includes('mac')){
    document.querySelector("body").style.fontFamily = "Helvetica";
    document.querySelector(".sponsors").style.fontSize = "11px";
    document.querySelector("body").style.fontSize = "12px";
    document.querySelector(".contextMenuFilter").style.fontSize = "11px";
}

// var port = chrome.extension.connect({name: "Sample Communication"});
var port = browserType.runtime.connect({name: "Sample Communication"});

browserType.runtime.onMessage.addListener(function(request, sender, sendResponse) {
// chrome.extension.onMessage.addListener(function(request, sender, sendResponse) {
    if(request.message === 'AttachStudio') {
        openedRecorder = true;
    }
    if(request.message === 'DeattachStudio') {
        openedRecorder = false;
    }
});

// recorderOpen.addEventListener('click', function() {
//     // if(openedRecorder) {
//     //     port.postMessage({ name: 'active' });    

//     //     return;
//     // }
//     openedRecorder = true;
//     port.postMessage({ name: 'openStudio' });

// });

var toggleElement = document.querySelector(".toggle-btn");
// var contextMenuFilter = document.querySelector(".contextMenuFilter");

toggleElement.addEventListener("click", function() {
    trackEvent("ContextMenu Toggle");
    toggleAction();
    var contextMenu = toggleElement.className;
    browserType.runtime.sendMessage({ contextMenu: contextMenu });
});

function toggleAction(){
   
  if(toggleElement.classList.contains("active")) {
    
    browserType.storage.local.set({'toggleElement':'inactive'}, function(){});
    toggleElement.classList.remove("active");
    toggleElement.classList.add("inactive");
    //contextMenuFilter.style.display = "none";
    
  } else {
    browserType.storage.local.set({'toggleElement':'active'}, function(){});
    toggleElement.classList.remove("inactive");
    toggleElement.classList.add("active"); 
    //contextMenuFilter.style.display = "block";
  }

  var toggleBtnToolTip = document.querySelector(".toggle.toolTip");
  if(toggleElement.classList.contains("inactive")){
        toggleBtnToolTip.textContent = "Turn on contextMenu.";
  } else{
    toggleBtnToolTip.textContent = "Turn off contextMenu.";
  }
}

// var relXpathOption = document.querySelector(".chooseSelector.relXpath");
// var cssSelectorOption = document.querySelector(".chooseSelector.cssSelector");
// var jspathOption = document.querySelector(".chooseSelector.jspath");
// var absXpathOption = document.querySelector(".chooseSelector.absXpath");

setTimeout(function(){ 
    browserType.storage.local.get(['toggleElement'], function(result){
        
        if(result.toggleElement=="inactive") { 
            toggleElement.classList.remove("active");
            toggleElement.classList.add("inactive");
            //contextMenuFilter.style.display = "none";
        }
        var toggleBtnToolTip = document.querySelector(".toggle.toolTip");
          if(toggleElement.classList.contains("inactive")){
            toggleBtnToolTip.textContent = "Turn on contextMenu.";
          } else{
            toggleBtnToolTip.textContent = "Turn off contextMenu.";
          }
    });

    // browserType.storage.local.get(['relXpathChecked'], function(result){
    //     result.relXpathChecked = result.relXpathChecked == undefined ? "relXpathOn" : result.relXpathChecked;
    //     relXpathOption.checked = result.relXpathChecked == "relXpathOn" ? true : false;
    // });

    // browserType.storage.local.get(['cssSelectorChecked'], function(result){
    //     result.cssSelectorChecked = result.cssSelectorChecked == undefined ? "cssSelectorOff" : result.cssSelectorChecked;
    //     cssSelectorOption.checked = result.cssSelectorChecked == "cssSelectorOn" ? true : false;
    // });

    // browserType.storage.local.get(['jspathChecked'], function(result){
    //     result.jspathChecked = result.jspathChecked == undefined ? "jspathOff" : result.jspathChecked;
    //     jspathOption.checked = result.jspathChecked == "jspathOn" ? true : false;
    // });

    // browserType.storage.local.get(['absXpathChecked'], function(result){
    //     result.absXpathChecked = result.absXpathChecked == undefined ? "absXpathOff" : result.absXpathChecked;
    //     absXpathOption.checked = result.absXpathChecked == "absXpathOn" ? true : false;
    // });

}, 500);


// relXpathOption.addEventListener("click", function() { 
//     var relXpathChecked = relXpathOption.checked ? "relXpathOn" : "relXpathOff";
//     browserType.storage.local.set({'relXpathChecked' : relXpathChecked}, function(){});  
//     browserType.runtime.sendMessage({ relXpathChecked: relXpathChecked });
// });

// cssSelectorOption.addEventListener("click", function() { 
//     var cssSelectorChecked = cssSelectorOption.checked ? "cssSelectorOn" : "cssSelectorOff";
//     browserType.storage.local.set({'cssSelectorChecked' : cssSelectorChecked}, function(){});  
//     browserType.runtime.sendMessage({ cssSelectorChecked: cssSelectorChecked });
// });


// jspathOption.addEventListener("click", function() { 
//     var jspathChecked = jspathOption.checked ? "jspathOn" : "jspathOff";
//     browserType.storage.local.set({'jspathChecked' : jspathChecked}, function(){});  
//     browserType.runtime.sendMessage({ jspathChecked: jspathChecked });
// });


// absXpathOption.addEventListener("click", function() { 
//     var absXpathChecked = absXpathOption.checked ? "absXpathOn" : "absXpathOff";
//     browserType.storage.local.set({'absXpathChecked' : absXpathChecked}, function(){});  
//     browserType.runtime.sendMessage({ absXpathChecked: absXpathChecked });
//});

function popup() {
    var className = document.querySelector(".toggle-btn").className;
    chrome.tabs.query({currentWindow: true, active: true}, function (tabs){
    var activeTab = tabs[0];
    chrome.tabs.sendMessage(activeTab.id, {"name": className});
   });
}

// function popupRelXpath() {
//     var relXpathCheckedForContent = relXpathOption.checked ? "relXpathOn" : "relXpathOff";
//     chrome.tabs.query({currentWindow: true, active: true}, function (tabs){
//     var activeTab = tabs[0];
//     chrome.tabs.sendMessage(activeTab.id, {"name": relXpathCheckedForContent});
//    });
// }

// function popupCssSelector() {
//     var cssSelectorCheckedForContent = "cssSelectorOn";
//     if(cssSelectorOption.checked || jspathOption.checked){
//         cssSelectorCheckedForContent = "cssSelectorOn";
//     }else{
//         cssSelectorCheckedForContent = "cssSelectorOff";
//     }
    
//     chrome.tabs.query({currentWindow: true, active: true}, function (tabs){
//     var activeTab = tabs[0];
//     chrome.tabs.sendMessage(activeTab.id, {"name": cssSelectorCheckedForContent});
//    });
// }

document.addEventListener("DOMContentLoaded", function() {
    toggleElement.addEventListener("click", popup);
    //relXpathOption.addEventListener("click", popupRelXpath);
    //cssSelectorOption.addEventListener("click", popupCssSelector);
    //jspathOption.addEventListener("click", popupCssSelector);
});

